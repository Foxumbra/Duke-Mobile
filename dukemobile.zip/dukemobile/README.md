# Duke Nukem Mobile

A touch-friendly Android port of the original **Duke Nukem 1** (Apogee, 1991), built as a
JavaScript engine running in a WebView. The engine logic is derived from
[FreeNukum](https://crates.io/crates/freenukum) by Wolfgang Silbermayr (AGPL-3.0-or-later), rewritten in JavaScript.

**No game data is included.** On first launch you import your own copy of the game files
(the shareware zip, or the individual `*.DN1` files plus `STRINGS.TXT`). They are stored in the
app's private storage (IndexedDB) and never leave the device.

## Layout
- `web/` – the game (ES modules, canvas 320x200, WebAudio). Runs in any modern browser too:
  `cd web && python3 -m http.server`, then open http://localhost:8000.
- `android/` – Android Studio project; its Gradle build copies `web/` into the APK's assets.
- `.github/workflows/build.yml` – builds a debug APK on GitHub Actions (artifact: `DukeMobile-debug-apk`).

## Build the APK
**Android Studio:** open the `android/` folder, let it sync (it creates the Gradle wrapper), then
*Build > Build APK(s)*. Or from a shell with Gradle 8.7+, JDK 17 and the Android SDK:
`gradle -p android assembleDebug` -> `android/app/build/outputs/apk/debug/`.

**GitHub:** push this folder to a repository; the workflow produces the APK as a downloadable artifact.

## Controls
On-screen buttons: left/right, JUMP, FIRE, USE (doors, keyholes, notes), MENU. Android Back = menu.
Keyboard: arrows / A D, Ctrl / Space / Z jump, Alt / Shift / X fire, Up / W use, Esc menu.
Gamepads work through the browser Gamepad API.

## Fidelity status
Ported from FreeNukum: level loading, tiles, hero physics, most enemies and hazards, HUD, menus, saves,
sound (PC-speaker banks), hallways and level flow.
**Reconstructed (FreeNukum has no code for these, so behaviour is approximate):** flying techbots,
bunny bots, fire gnomes, water, and the Dr. Proton boss fight/ending.
**Not yet implemented:** helicopter bots (they are invisible and harmless), touch-triggered hint texts,
high-score table, the demo/preview screens, and PKWARE-imploded zip entries (use stored/deflate zips or
loose files).

## License
AGPL-3.0-or-later. Contains code derived from FreeNukum, (c) Wolfgang Silbermayr. Duke Nukem is a
trademark of its owners; the original game data is not distributed here.
