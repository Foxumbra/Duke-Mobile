// SPDX-License-Identifier: AGPL-3.0-or-later
// Game flow derived from FreeNukum game.rs (c) Wolfgang Silbermayr, ported to JavaScript.
import {
  GAME_INTERVAL, LEVELWINDOW_WIDTH, LEVELWINDOW_HEIGHT, LEVEL_WIDTH, LEVEL_HEIGHT,
  TILE_WIDTH as W, TILE_HEIGHT as H, WINDOW_WIDTH, WINDOW_HEIGHT,
} from './consts.js';
import { Rect, Dir, idiv } from './rect.js';
import { Hero, Motion } from './hero.js';
import { Level, CommandQueue } from './level.js';
import { renderHud, drawMessageBox, messageBoxSize } from './hud.js';
import { GameData } from './gamedata.js';

const SAVE_KEY = (slot) => `dukemobile.save.${slot}`;
const SETTINGS_KEY = 'dukemobile.settings';
const AUTOFIRE_TICKS = 3;

const sleepFrame = () => new Promise((r) => requestAnimationFrame(r));

export class Game {
  constructor({ renderer, input, sound }) {
    this.r = renderer; this.input = input; this.sound = sound;
    this.data = null; this.images = new Map();
    this.settings = { hints: true, sound: true, autofire: true };
    try { Object.assign(this.settings, JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}')); } catch {}
    this.sound.enabled = this.settings.sound;
    this.menuHit = null;
    this.quitRequested = false;
  }

  saveSettings() { try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(this.settings)); } catch {} }

  setData(data) {
    this.data = data;
    this.r.setTiles(data.tiles());
    this.sound.setBank(data.sounds());
    this.images.clear();
  }

  // ------------------------------------------------------------------ UI helpers
  image(kind, key) {
    const id = kind + ':' + key;
    if (!this.images.has(id)) {
      const raw = kind === 'pic' ? this.data.picture(key) : this.data.backdrop(key);
      this.images.set(id, raw ? this.r.makeImage(raw) : null);
    }
    return this.images.get(id);
  }
  tap(x, y) {
    if (this.menuHit) this.menuHit(x, y);
    else this.input.resolveWaiters('tap');
  }
  str(name) { return this.data.strings.get(name).join('\n'); }

  /** Shows a message box (centered unless x,y given) and waits for confirmation. */
  async box(text, { x, y, wait = true } = {}) {
    const { w, h } = messageBoxSize(text);
    const bx = x ?? Math.floor((WINDOW_WIDTH - w) / 2 / 8) * 8, by = y ?? Math.floor((WINDOW_HEIGHT - h) / 2 / 8) * 8;
    drawMessageBox(this.r, text, bx, by);
    if (wait) await this.input.waitConfirm();
  }

  /** Menu box whose lines contain "X)" shortcuts. Resolves to the upper-case shortcut letter, or 'ESC'. */
  menu(text, { x, y } = {}) {
    const lines = text.split('\n');
    const { w, h } = messageBoxSize(text);
    const bx = x ?? Math.floor((WINDOW_WIDTH - w) / 2 / 8) * 8, by = y ?? Math.floor((WINDOW_HEIGHT - h) / 2 / 8) * 8;
    drawMessageBox(this.r, text, bx, by);
    return new Promise((resolve) => {
      let finished = false;
      const done = (v) => {
        if (finished) return;
        finished = true; this.menuHit = null; this.input.off('anykey'); this.input.off('press'); resolve(v);
      };
      this.menuHit = (px, py) => {
        const row = Math.floor((py - by - 8) / 8);
        if (px < bx || px > bx + w || row < 0 || row >= lines.length) return;
        const m = /(\w)\)/.exec(lines[row]);
        if (m) done(m[1].toUpperCase());
      };
      this.input.on('anykey', (e) => done(e.key.length === 1 ? e.key.toUpperCase() : 'ESC'));
      this.input.on('press', (b) => { if (b === 'menu') done('ESC'); });
    });
  }

  async splash(pic, message, mx, my) {
    const img = this.image('pic', pic);
    this.r.clear();
    if (img) this.r.placeImage(img, 0, 0);
    if (message) drawMessageBox(this.r, message, mx, my);
    await this.input.waitConfirm();
  }

  async textPage(name) {
    this.r.clear();
    this.r.text(this.str(name), 0, 0);
    await this.input.waitConfirm();
  }

  // ------------------------------------------------------------------ main menu
  async mainMenu() {
    for (;;) {
      this.r.clear();
      const title = this.image('pic', 'DN');
      if (title) this.r.placeImage(title, 0, 0);
      let lines = this.data.strings.get('MAIN_MENU');
      const choice = await this.menu(lines.join('\n'));
      this.sound.unlock();
      switch (choice) {
        case 'S': if (await this.newGame(null)) return; break;
        case 'R': { const sg = await this.askRestore(); if (sg) { if (await this.newGame(sg)) return; } break; }
        case 'I': await this.showInstructions(); break;
        case 'O': if (this.data.strings.has('ORDER1')) { await this.textPage('ORDER1'); await this.textPage('ORDER2'); } break;
        case 'G': await this.gameSetup(); break;
        case 'H': await this.showHighScores(); break;
        case 'T': await this.splash('DN', null); break;
        case 'C': await this.splash('CREDITS', null); break;
        case 'Q': this.quitRequested = true; return;
        default: break;
      }
    }
  }

  async showInstructions() {
    if (this.data.strings.has('STORY1')) await this.textPage('STORY1');
    await this.box(MOBILE_HELP);
  }

  async gameSetup() {
    for (;;) {
      this.r.clear();
      const t = `        GAME SETUP\n\n  S)ound: ${this.settings.sound ? 'ON ' : 'OFF'}\n  H)ints: ${this.settings.hints ? 'ON ' : 'OFF'}\n  A)utofire: ${this.settings.autofire ? 'ON ' : 'OFF'}\n\n  B)ack`;
      const c = await this.menu(t);
      if (c === 'S') { this.settings.sound = !this.settings.sound; this.sound.enabled = this.settings.sound; }
      else if (c === 'H') this.settings.hints = !this.settings.hints;
      else if (c === 'A') this.settings.autofire = !this.settings.autofire;
      else { this.saveSettings(); return; }
    }
  }

  async showHighScores() { await this.box('  --- HIGH  SCORES ---  \n\n   (none recorded yet)   '); }

  // ------------------------------------------------------------------ savegames
  readSave(slot) { try { return JSON.parse(localStorage.getItem(SAVE_KEY(slot))); } catch { return null; } }
  writeSave(slot, sg) { localStorage.setItem(SAVE_KEY(slot), JSON.stringify(sg)); }

  async askSlot(promptName) {
    const text = this.str(promptName);
    for (;;) {
      const c = await this.menu(text);
      if (c === 'ESC') return null;
      if (/^[1-9]$/.test(c)) return Number(c);
    }
  }

  async askRestore() {
    const slot = await this.askSlot('RESTORE');
    if (slot === null) return null;
    const sg = this.readSave(slot);
    if (!sg) { await this.box(this.str('NOT_FOUND')); return null; }
    return sg;
  }

  // ------------------------------------------------------------------ game flow (game.rs `start`)
  /** Returns true if the whole app should exit to the main menu loop ending (never), false to return to menu. */
  async newGame(savegame) {
    const hero = new Hero();
    let levelNumber = 1, interlevel = false, gameId = crypto.randomUUID ? crypto.randomUUID() : String(Date.now());
    if (savegame) {
      levelNumber = savegame.finishedLevel;
      hero.health.set(savegame.health);
      hero.firepower.set(savegame.firepower);
      hero.score.setValue(savegame.score);
      for (const it of savegame.inventory) hero.inventory.set(it);
      gameId = savegame.gameId; interlevel = true;
    } else {
      await this.prelude();
    }
    let initial = { life: hero.health.life, score: hero.score.value(), items: hero.inventory.getItems() };
    for (;;) {
      if (interlevel) {
        const res = await this.playLevel({ hero, levelNumber, interlevel, gameId });
        if (res === 'NextLevel') {
          initial = { life: hero.health.life, score: hero.score.value(), items: hero.inventory.getItems() };
          levelNumber += 1; interlevel = false;
        } else return false;
      } else {
        hero.resetForLevel();
        hero.health.set(initial.life ?? 8);
        hero.score.setValue(initial.score);
        hero.inventory.setItems(initial.items);
        const res = await this.playLevel({ hero, levelNumber, interlevel, gameId });
        if (res === 'Finale') { await this.finale(); return false; }
        if (res === 'NextLevel') {
          if (levelNumber >= 11 || !this.data.level(GameData.levelFileHex(levelNumber + 1, false))) { await this.finale(); return false; }
          interlevel = true;
        } else if (res === 'RestartLevel') { /* loop */ } else return false;
      }
    }
  }

  async prelude() {
    await this.splash('BADGUY', this.str('INTRO1'), 0, 144);
    await this.splash('DUKE', this.str('INTRO2'), 79, 144);
    this.r.clear();
    await this.box(this.str('GOING_IN'));
    this.sound.play('STARTGAME');
  }

  async finale() {
    this.r.clear();
    await this.splash('END', null);
    this.r.clear();
    this.r.text(this.str('FINALE'), 8, 8);
    await this.input.waitConfirm();
  }

  // ------------------------------------------------------------------ playing a level
  levelMessageIndex(levelNumber, interlevel) { return interlevel ? (levelNumber - 1) * 2 + 1 : (levelNumber - 1) * 2; }

  async showInfo(msg, ctx) {
    if (typeof msg === 'string') { await this.box(msg.replace(/\n$/, '')); return; }
    if (msg && msg.note) {
      const name = 'MESSAGE_' + this.levelMessageIndex(ctx.levelNumber, ctx.interlevel);
      const lines = this.data.strings.has(name) ? this.data.strings.get(name) : null;
      if (lines && lines.some((l) => l.trim())) await this.box(lines.join('\n') + '\n\n      Press ENTER:      ');
    }
  }

  /** Mirrors start_in_level(); resolves to 'NextLevel' | 'RestartLevel' | 'GoToMainScreen'. */
  async playLevel({ hero, levelNumber, interlevel, gameId }) {
    const hex = GameData.levelFileHex(levelNumber, interlevel);
    const bytes = this.data.level(hex);
    if (!bytes) { await this.box(`Level file WORLDAL${hex}.DN1\nnot found.`); return 'GoToMainScreen'; }
    const level = Level.load(bytes, hero);
    const backdrop = this.image('drop', this.data.backdropNumber(interlevel ? Math.max(1, levelNumber) : levelNumber));

    const cmds = new CommandQueue(), msgs = [], infos = [];
    const info = (m) => infos.push(m);
    const winW = LEVELWINDOW_WIDTH * W, winH = LEVELWINDOW_HEIGHT * H;
    const g0 = hero.position.geometry;
    const view = new Rect(Math.max(0, g0.x + W - winW / 2), Math.max(0, g0.y - winH / 2), winW, winH);

    // ---- input wiring
    let left = false, right = false, menuRequested = false, fireTicks = 0, escapeToMenu = false;
    const updateMotion = () => {
      if (left === right) hero.motion = Motion.NotMoving;
      else { hero.motion = Motion.Walking; hero.direction = left ? Dir.Left : Dir.Right; }
    };
    this.input.on('press', (b) => {
      if (b === 'left') { left = true; updateMotion(); }
      else if (b === 'right') { right = true; updateMotion(); }
      else if (b === 'jump') hero.jump(level.tiles, cmds);
      else if (b === 'fire') { hero.isShooting = true; level.fireShot(hero, cmds, msgs); fireTicks = 0; }
      else if (b === 'use') level.heroInteractStart(hero, cmds, msgs, info);
      else if (b === 'menu') menuRequested = true;
    });
    this.input.on('release', (b) => {
      if (b === 'left') { left = false; updateMotion(); }
      else if (b === 'right') { right = false; updateMotion(); }
      else if (b === 'fire') hero.isShooting = false;
      else if (b === 'use') level.heroInteractEnd(hero);
    });
    // buttons may already be held when the level starts
    left = this.input.isHeld('left'); right = this.input.isHeld('right'); updateMotion();
    const cleanup = () => { this.input.off('press'); this.input.off('release'); };

    let result = null;
    let last = performance.now(), acc = 0;
    const ctx = { levelNumber, interlevel };
    const draw = () => this.drawLevel(level, hero, view, backdrop);
    draw();
    try {
      while (level.keepActing) {
        await sleepFrame();
        this.input.pollGamepad();
        const now = performance.now();
        acc += Math.min(now - last, 250); last = now;
        let ticked = false;
        while (acc >= GAME_INTERVAL && level.keepActing) {
          acc -= GAME_INTERVAL;
          const playSounds = [];
          if (this.settings.autofire && this.input.isHeld('fire') && ++fireTicks >= AUTOFIRE_TICKS) {
            fireTicks = 0; level.fireShot(hero, cmds, msgs);
          }
          level.act(hero, cmds, msgs, playSounds, view, info);
          for (const s of cmds.sounds.splice(0)) playSounds.push(s);
          for (const s of playSounds) this.sound.play(s);
          ticked = true;
          // death animation / camera (the `do_update` part of the original loop)
          const ps = level.playState;
          if (ps.kind === 'KilledPlayingAnimation') {
            if (ps.n === 0) level.playState = { kind: 'RestartLevel' };
            else {
              hero.hidden = true;
              if (ps.n > 30 && ps.n % 2 === 0) cmds.addParticleFirework(hero.position.geometry.center(), 4);
              ps.n -= 1;
            }
          }
          const g = hero.position.geometry;
          view.x = Math.min(Math.max(0, g.center().x - winW / 2), LEVEL_WIDTH * H - winW);
          view.y = Math.min(Math.max(0, g.y - winH / 2), LEVEL_HEIGHT * H - winH);
          if (infos.length || menuRequested) break;
        }
        if (ticked) draw();
        if (infos.length) {
          while (infos.length) await this.showInfo(infos.shift(), ctx);
          last = performance.now(); acc = 0; draw();
        }
        if (menuRequested) {
          menuRequested = false;
          const act = await this.inLevelMenu({ hero, level, levelNumber, interlevel, gameId, cmds });
          if (act === 'GoToMainScreen') level.playState = { kind: 'GoToMainScreen' };
          else if (act === 'Restart') level.playState = { kind: 'RestartLevel' };
          last = performance.now(); acc = 0; draw();
        }
        // buttons may have changed while a modal box was open
        if (!level.keepActing) break;
        if (left !== this.input.isHeld('left') || right !== this.input.isHeld('right')) {
          left = this.input.isHeld('left'); right = this.input.isHeld('right'); updateMotion();
        }
      }
    } finally { cleanup(); hero.isShooting = false; level.heroInteractEnd(hero); }
    const k = level.playState.kind;
    result = k === 'LevelFinished' ? (level.bossDefeated ? 'Finale' : 'NextLevel') : k === 'GoToMainScreen' ? 'GoToMainScreen' : 'RestartLevel';
    if (result === 'RestartLevel') {
      this.r.clear();
      await this.box(this.str('DIED') + '\n' + '      Press ENTER:      ');
    }
    return result;
  }

  drawLevel(level, hero, view, backdrop) {
    const r = this.r;
    r.clear();
    r.ox = 0; r.oy = 0;
    renderHud(r, hero);
    r.clip(W, H, LEVELWINDOW_WIDTH * W, LEVELWINDOW_HEIGHT * H);
    r.ox = -view.x + W; r.oy = -view.y + H;
    level.render(r, hero, view, backdrop);
    r.unclip();
    r.ox = 0; r.oy = 0;
  }

  async inLevelMenu({ hero, level, levelNumber, interlevel, gameId }) {
    this.sound.stopAll();
    for (;;) {
      const text = interlevel
        ? '\n      DUKE HELP MENU\n      --------------\n\n      S)ave a game\n      I)nstructions\n      G)ame Setup\n      R)estart Level\n      Q)uit to main menu\n'
        : '\n      DUKE HELP MENU\n      --------------\n\n      I)nstructions\n      G)ame Setup\n      R)estart Level\n      Q)uit to main menu\n';
      const c = await this.menu(text);
      if (c === 'ESC') return null;
      if (c === 'S' && interlevel) {
        const slot = await this.askSlot('SAVE');
        if (slot) {
          this.writeSave(slot, hero.createSavegame(gameId, levelNumber));
          await this.box(this.str('SAVED'));
        }
        return null;
      }
      if (c === 'S') { await this.box(this.str('CANNOT_SAVE')); continue; }
      if (c === 'I') { await this.box(MOBILE_HELP); return null; }
      if (c === 'G') { await this.gameSetup(); return null; }
      if (c === 'R') { return 'Restart'; }
      if (c === 'Q') return 'GoToMainScreen';
    }
  }
}

const MOBILE_HELP =
`       Instructions
Touch controls:
  < >   - Walk
  JUMP  - Jump
  FIRE  - Fire (hold to rapid fire)
  USE   - Action key: open doors,
          use keys, elevators,
          teleporters, read notes
  MENU  - Help menu / save

Keyboard: arrows, Ctrl/Space jump,
Alt/X fire, Up action, Esc menu.

     Press any key.     `;
