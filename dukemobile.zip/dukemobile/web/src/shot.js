// SPDX-License-Identifier: AGPL-3.0-or-later
// Derived from FreeNukum shot.rs (c) Wolfgang Silbermayr, ported to JavaScript.
import { TILE_WIDTH as W, TILE_HEIGHT as H, HALFTILE_WIDTH as HW, LEVELWINDOW_WIDTH, OBJECT_SHOT } from './consts.js';
import { Rect, dirFactor, idiv } from './rect.js';
import { T } from './actors/base.js';

export class Shot {
  constructor(x, y, direction) {
    const w = idiv(W, 4), h = idiv(H, 4) * 3;
    this.position = new Rect(x + W - idiv(w, 2) + dirFactor(direction) * w, y + H - h, w, h);
    this.isAlive = true; this.direction = direction; this.counter = 0; this.countdown = 2;
  }

  /** ctx: { hero, level(actors,tiles), cmds, msgs } */
  act(ctx) {
    this.counter = (this.counter + 1) % 4;
    if (this.countdown === 1) { this.isAlive = false; this.countdown -= 1; }
    const g = ctx.hero.position.geometry;
    const xStart = g.x - W * LEVELWINDOW_WIDTH / 2;
    const xEnd = g.x + g.w + W * LEVELWINDOW_WIDTH / 2;
    if (this.countdown >= 2) {
      const distance = HW * dirFactor(this.direction);
      // pushed in two half steps so the intermediate position is covered as well
      this.push(ctx, distance);
      this.push(ctx, distance);
      if (this.position.x < xStart || this.position.x > xEnd) this.countdown = 1;
    }
    return this.isAlive;
  }

  push(ctx, offset) {
    const { level, hero, cmds, msgs } = ctx;
    if (this.countdown >= 2) {
      this.position.x += offset;
      if (this.countdown === 2) {
        if (level.actors.processShot(this.position, { tiles: level.tiles, cmds, hero, msgs, level })) this.countdown = 1;
      } else this.countdown -= 1;
    }
    if (this.countdown >= 2 && level.tiles.collides(this.position)) {
      this.countdown = 1;
      cmds.addActor(T('SingleAnimation', { a: 'Explosion' }), this.position.topLeft().offset(idiv(this.position.w, 2) - HW, 0));
    }
  }

  render(r) {
    if (!this.isAlive) return;
    const x = this.position.x + idiv(this.position.w, 2) - HW;
    r.placeTile(OBJECT_SHOT + this.counter, x, this.position.y);
  }
}
