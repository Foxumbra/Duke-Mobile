// SPDX-License-Identifier: AGPL-3.0-or-later
// Parser for ReDuke-style string definition files (STRINGS.TXT) plus plain fallback texts.

export function parseStrings(text) {
  const lines = text.replace(/\r/g, '').split('\n');
  const out = new Map();
  for (let i = 0; i < lines.length;) {
    const m = /^(\d+)[ \t]+(\S+)/.exec(lines[i]);
    if (m && Number(m[1]) > 0) {
      const n = Number(m[1]);
      out.set(m[2], lines.slice(i + 1, i + 1 + n));
      i += 1 + n;
    } else i += 1;
  }
  return out;
}

/** Fallback texts (written for this port) used when no STRINGS.TXT was imported. */
export const FALLBACK = {
  MAIN_MENU: ['', '     DUKE MAIN MENU', '     --------------', '', '  S)tart a new game', '  R)estore an old game', '  I)nstructions', '  C)redits'],
  HELP_MENU: ['', '      HELP MENU', '      ---------', '', '  S)ave a game', '  R)estart level', '  Q)uit to menu'],
  GOING_IN: ['     Get ready Duke,', "    you're going in!!"],
  DIED: ['     You have died.', 'Bringing you back to the', '   last main hallway.'],
  PRESS_ENTER: ['      Press ENTER:'],
  ANY_KEY: ['     Press any key.'],
  INTRO1: ["So you're the pitiful", 'hero they sent to stop', 'me.  I, Dr. Proton, will', 'soon rule the world!'],
  INTRO2: ["You're wrong, Proton", "breath.  I'll be done", 'with you and still have', 'time to watch Oprah!'],
  SAVED: ['   Your game is saved.'],
  NOT_FOUND: ['     Game not found'],
  INSTRUCTIONS: ['', ' Left/Right  walk', ' Jump        jump', ' Fire        shoot', ' Up          use doors, keys,', '             elevators, notes'],
  FINALE: ['     TO BE CONTINUED'],
};

export class Strings {
  constructor(map) { this.map = map ?? new Map(); }
  get(name) { return this.map.get(name) ?? FALLBACK[name] ?? [name]; }
  has(name) { return this.map.has(name); }
  text(name) { return this.get(name).join('\n'); }
}
