// SPDX-License-Identifier: AGPL-3.0-or-later
// Minimal ZIP reader: stored (0), deflate (8) via DecompressionStream, and PKWARE "implode" (6).
import { explode } from './implode.js';

const u16 = (b, o) => b[o] | (b[o + 1] << 8);
const u32 = (b, o) => (b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)) >>> 0;

async function inflateRaw(data) {
  const ds = new DecompressionStream('deflate-raw');
  const stream = new Blob([data]).stream().pipeThrough(ds);
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

/** Returns Map<UPPERCASE_BASENAME, Uint8Array> of every file in the archive. */
export async function readZip(buffer) {
  const b = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  let eocd = -1;
  for (let i = b.length - 22; i >= Math.max(0, b.length - 22 - 65535); i--) {
    if (u32(b, i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('Not a ZIP file (no end-of-central-directory record).');
  const count = u16(b, eocd + 10);
  let p = u32(b, eocd + 16);
  const out = new Map();
  for (let i = 0; i < count; i++) {
    if (u32(b, p) !== 0x02014b50) throw new Error('Corrupt ZIP central directory.');
    const flags = u16(b, p + 8), method = u16(b, p + 10);
    const csize = u32(b, p + 20), usize = u32(b, p + 24);
    const nlen = u16(b, p + 28), xlen = u16(b, p + 30), clen = u16(b, p + 32);
    const lho = u32(b, p + 42);
    const name = new TextDecoder().decode(b.subarray(p + 46, p + 46 + nlen));
    p += 46 + nlen + xlen + clen;
    if (name.endsWith('/')) continue;
    const lnlen = u16(b, lho + 26), lxlen = u16(b, lho + 28);
    const start = lho + 30 + lnlen + lxlen;
    const raw = b.subarray(start, start + csize);
    let data;
    if (method === 0) data = raw.slice();
    else if (method === 8) data = await inflateRaw(raw);
    else if (method === 6) data = explode(raw, usize, flags);
    else throw new Error(`Unsupported ZIP compression method ${method} for ${name}`);
    out.set(name.split('/').pop().toUpperCase(), data);
  }
  return out;
}
