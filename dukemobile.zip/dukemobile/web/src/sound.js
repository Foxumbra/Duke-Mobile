// SPDX-License-Identifier: AGPL-3.0-or-later
// WebAudio playback of the PC-speaker sounds decoded by assets.js (max 5 concurrent sounds).
import { SAMPLE_RATE } from './assets.js';

const MAX_CHANNELS = 5;

export class SoundPlayer {
  constructor() { this.bank = new Map(); this.buffers = new Map(); this.ctx = null; this.channels = []; this.enabled = true; this.volume = 1.0; this.gain = null; }
  setBank(map) { this.bank = map; this.buffers.clear(); }
  /** Must be called from a user gesture on mobile browsers. */
  unlock() {
    if (!this.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.gain = this.ctx.createGain();
      this.gain.gain.value = this.volume;
      this.gain.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') this.ctx.resume();
  }
  setVolume(v) { this.volume = v; if (this.gain) this.gain.gain.value = v; }
  buffer(name) {
    let b = this.buffers.get(name);
    if (!b) {
      const data = this.bank.get(name);
      if (!data || data.length === 0) return null;
      b = this.ctx.createBuffer(1, data.length, SAMPLE_RATE);
      b.copyToChannel(data, 0);
      this.buffers.set(name, b);
    }
    return b;
  }
  play(name) {
    if (!this.enabled || !this.ctx) return;
    const buf = this.buffer(name);
    if (!buf) return;
    // the same sound restarts; otherwise drop the oldest when all channels are busy
    const same = this.channels.findIndex((c) => c.name === name);
    if (same >= 0) { try { this.channels[same].src.stop(); } catch {} this.channels.splice(same, 1); }
    while (this.channels.length >= MAX_CHANNELS) { try { this.channels[0].src.stop(); } catch {} this.channels.shift(); }
    const src = this.ctx.createBufferSource();
    src.buffer = buf; src.connect(this.gain);
    const entry = { name, src };
    src.onended = () => { const i = this.channels.indexOf(entry); if (i >= 0) this.channels.splice(i, 1); };
    this.channels.push(entry);
    src.start();
  }
  stopAll() { for (const c of this.channels) { try { c.src.stop(); } catch {} } this.channels = []; }
}
