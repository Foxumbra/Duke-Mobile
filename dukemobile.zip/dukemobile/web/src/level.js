// SPDX-License-Identifier: AGPL-3.0-or-later
// Derived from FreeNukum level.rs and the command queue of game.rs
// (c) Wolfgang Silbermayr, ported to JavaScript.
import {
  LEVEL_WIDTH, LEVEL_HEIGHT, TILE_WIDTH as W, TILE_HEIGHT as H, ANIMATION_START, SOLID_BLACK,
  SOLID_CONVEYORBELT_LEFTEND, KeyColor,
} from './consts.js';
import { LevelTiles } from './tiles.js';
import { ActorsList, createActor } from './actors/index.js';
import { T } from './actors/base.js';
import { Shot } from './shot.js';
import { Point, Rect, Dir, dirFactor, idiv } from './rect.js';

const PARTICLE_COLORS = ['Pink', 'Blue', 'White', 'Green'];

/** GameCommandQueue: collects actors/sounds; `process` forwards them to a destination. */
export class CommandQueue {
  constructor() { this.actors = []; this.sounds = []; }
  addActor(type, pos) { this.actors.push({ type, pos }); }
  addSound(name) { this.sounds.push(name); }
  addParticleFirework(pos, count) {
    for (let i = 0; i < count; i++) this.addActor(T('Particle', { c: PARTICLE_COLORS[Math.floor(Math.random() * 4)] }), pos);
  }
  process(dest) {
    const a = this.actors, s = this.sounds;
    this.actors = []; this.sounds = [];
    for (const { type, pos } of a) dest.addActor(type, pos);
    for (const n of s) dest.addSound(n);
  }
}

/** LevelCommandProcessor: instantiates queued actors inside the level. */
class LevelCommandProcessor {
  constructor(tiles, actors, playSounds, copyBackground) {
    this.tiles = tiles; this.actors = actors; this.playSounds = playSounds; this.copyBackground = copyBackground;
  }
  addActor(type, pos) {
    const actor = createActor(type, pos, this.tiles);
    if (this.copyBackground) {
      const x = idiv(pos.x, W), y = idiv(pos.y, H);
      const s = actor.backgroundTileStrategy();
      const eff = (xx, yy) => { const t = this.tiles.get(xx, yy); return t ? t.effective : 0; };
      let n;
      switch (s.k) {
        case 'KeepEmpty': n = 0; break;
        case 'SetTile': n = s.n; break;
        case 'CopyFromAbove': n = eff(x, y - 1); break;
        case 'CopyFromLeft': n = eff(x - 1, y); break;
        case 'CopyFromRight': n = eff(x + 1, y); break;
        case 'CopyFromBelow': n = eff(x, y + 1); break;
      }
      const t = this.tiles.get(x, y);
      if (t) t.effective = n;
    }
    this.actors.actors.push(actor);
  }
  addSound(name) { this.playSounds.push(name); }
  addParticleFirework(pos, count) { CommandQueue.prototype.addParticleFirework.call(this, pos, count); }
}

const BG = (a) => T('BackgroundAnimation', { a });
const GREY = (c) => T('Item', { it: 'BoxGrey.' + c });
const BLUE = (c) => T('Item', { it: 'BoxBlue.' + c });
const RED = (c) => T('Item', { it: 'BoxRed.' + c });
const L = Dir.Left, R = Dir.Right;

// Level word -> actor type for 0x3000..0x3059 (plus the background animations below 0x3000).
const FLASHERS = {
  0x0080: 'TextOnScreen', 0x0100: 'HighVoltageFlash', 0x0180: 'RedFlashlight', 0x0200: 'BlueFlashlight',
  0x0280: 'Keypanel', 0x0300: 'RedRotationLight', 0x0380: 'UpArrow', 0x0400: 'BlueLight1',
  0x0420: 'BlueLight2', 0x0440: 'BlueLight3', 0x0460: 'BlueLight4', 0x0500: 'GreenPoison', 0x0580: 'Lava',
};
const ACTOR_CODES = {
  0x3000: GREY('Nothing'), 0x3001: T('Elevator'), 0x3003: T('ConveyorRightEnd', { dir: L }),
  0x3005: T('ConveyorRightEnd', { dir: R }), 0x3006: GREY('Boots'), 0x3007: T('Rocket'),
  0x3008: GREY('Clamps'), 0x3009: T('Fire', { dir: R }), 0x300a: T('Fire', { dir: L }),
  0x300b: T('FlyingBot'), 0x300c: T('JumpBot'), 0x300d: T('TankBot'), 0x300e: T('FireWheelBot'),
  0x300f: GREY('Gun'), 0x3010: T('Robot'), 0x3012: GREY('Bomb'), 0x3014: T('Water'),
  0x3015: RED('Soda'), 0x3016: T('WallCrawler', { dir: L }), 0x3017: T('WallCrawler', { dir: R }),
  0x3018: RED('Chicken'), 0x3019: T('UnstableFloor'), 0x301a: T('ElectricArc'),
  0x301b: T('Fan', { dir: L }), 0x301c: T('Fan', { dir: R }), 0x301d: BLUE('Football'),
  0x301e: BLUE('Joystick'), 0x301f: BLUE('Disk'), 0x3020: GREY('Glove'), 0x3021: T('AccessCardDoor'),
  0x3022: T('HelicopterBot'), 0x3023: BLUE('Balloon'), 0x3024: T('Camera'), 0x3025: BG('BrokenWall'),
  0x3028: BG('StoneWindow'), 0x3029: GREY('FullLife'), 0x302a: T('Acme'), 0x302b: T('Mill'),
  0x302c: T('Spikes', { sp: 'SingleSpikeUp' }), 0x302d: BLUE('Flag'), 0x302e: BLUE('Radio'),
  0x302f: T('Teleporter', { index: 'First' }), 0x3030: T('Teleporter', { index: 'Second' }),
  0x3031: T('MineJumping'), 0x3033: GREY('AccessCard'), 0x3034: T('AccessCardSlot'),
  0x3035: T('GloveSlot'), 0x3036: T('ExpandingFloor'), 0x3037: GREY('LetterD'), 0x3038: GREY('LetterU'),
  0x3039: GREY('LetterK'), 0x303a: GREY('LetterE'), 0x303b: T('RabbitoidBot'), 0x303c: T('FlameGnomeBot'),
  0x303d: T('FenceBackground'), 0x303e: BG('WindowLeft'), 0x303f: BG('WindowRight'),
  0x3040: T('NoteBook'), 0x3041: T('SurveillanceScreen'), 0x3043: T('DrProton'),
  0x3044: T('Key', { color: KeyColor.Red }), 0x3045: T('Key', { color: KeyColor.Green }),
  0x3046: T('Key', { color: KeyColor.Blue }), 0x3047: T('Key', { color: KeyColor.Pink }),
  0x3048: T('Keyhole', { color: KeyColor.Red }), 0x3049: T('Keyhole', { color: KeyColor.Green }),
  0x304a: T('Keyhole', { color: KeyColor.Blue }), 0x304b: T('Keyhole', { color: KeyColor.Pink }),
  0x304c: T('Door', { color: KeyColor.Red }), 0x304d: T('Door', { color: KeyColor.Green }),
  0x304e: T('Door', { color: KeyColor.Blue }), 0x304f: T('Door', { color: KeyColor.Pink }),
  0x3050: T('Item', { it: 'Football' }), 0x3051: T('Item', { it: 'ChickenSingle' }),
  0x3052: T('Item', { it: 'Soda' }), 0x3053: T('Item', { it: 'Disk' }), 0x3054: T('Item', { it: 'Joystick' }),
  0x3055: T('Item', { it: 'Flag' }), 0x3056: T('Item', { it: 'Radio' }),
  0x3057: T('MineLying'), 0x3058: T('Spikes', { sp: 'SpikesUp' }), 0x3059: T('Spikes', { sp: 'SpikesDown' }),
};
// codes that make the tile solid when placed
const SOLID_CODES = new Set([0x3001, 0x3014, 0x3021, 0x302a, 0x3036, 0x304c, 0x304d, 0x304e, 0x304f]);

export class Level {
  /**
   * @param {Uint8Array} data raw level file (LEVEL_WIDTH*LEVEL_HEIGHT little-endian words)
   * @param {Hero} hero
   */
  static load(data, hero) {
    const tiles = new LevelTiles();
    const queue = new CommandQueue();
    if (data.length < LEVEL_WIDTH * LEVEL_HEIGHT * 2) throw new Error('Level file too short');
    const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
    for (let i = 0; i < LEVEL_HEIGHT * LEVEL_WIDTH; i++) {
      const x = i % LEVEL_WIDTH, y = idiv(i, LEVEL_WIDTH);
      const tx = x * W, ty = y * H;
      const raw = view.getUint16(i * 2, true);
      const t = tiles.get(x, y);
      t.raw = raw;
      if (raw >= 4 && raw <= 0x2fe0) { t.solid = raw >= 0x1800; t.effective = idiv(raw, 0x20); }
      const add = (type, ax = tx, ay = ty) => queue.addActor(type, new Point(ax, ay));

      if (raw === 0) continue;
      if (FLASHERS[raw] !== undefined) { add(BG(FLASHERS[raw])); continue; }
      switch (raw) {
        case 0x1800: t.effective = idiv(0x17e0, 0x20); add(T('ShootableWall')); continue;
        case 0x1c00: t.effective = SOLID_BLACK; t.solid = true; continue;
        case 0x3002: case 0x3004: t.effective = SOLID_CONVEYORBELT_LEFTEND; t.solid = true; continue;
        case 0x3003: case 0x3005: t.effective = SOLID_BLACK; t.solid = true; add(ACTOR_CODES[raw]); continue;
        case 0x3011: add(T('ExitDoor'), tx, ty - H); continue;
        case 0x3013: for (let k = 0; k < 10; k++) add(T('FlyingBall', { i: k })); continue;
        case 0x3026: case 0x3027: continue; // TODO in FreeNukum as well
        case 0x3032: {
          hero.enterLevel(tx, ty - H);
          const left = tiles.get(x - 1, y);
          t.effective = left ? left.effective : 0;
          continue;
        }
        default: break;
      }
      if (ACTOR_CODES[raw] !== undefined) {
        if (SOLID_CODES.has(raw)) t.solid = true;
        add(ACTOR_CODES[raw]);
      } else if (raw >= 4 && raw <= 0x2fe0) {
        // plain tile
      } else if (idiv(raw, 0x20) >= ANIMATION_START) {
        console.warn(`Unknown tile 0x${raw.toString(16)} at ${x},${y}`);
        t.effective = 2;
      } else {
        console.warn(`Unknown tile code 0x${raw.toString(16)} at ${x},${y}`);
      }
    }
    const actors = new ActorsList();
    const sounds = [];
    queue.process(new LevelCommandProcessor(tiles, actors, sounds, true));
    return new Level(tiles, actors);
  }

  constructor(tiles, actors) {
    this.tiles = tiles; this.actors = actors; this.shots = [];
    this.playState = { kind: 'Playing' };
  }

  get keepActing() { return this.playState.kind === 'Playing' || this.playState.kind === 'KilledPlayingAnimation'; }
  get heroCanAct() { return this.playState.kind === 'Playing'; }

  heroInteractStart(hero, cmds, msgs, info) {
    this.actors.startInteraction({ hero, cmds, msgs, info, level: this, tiles: this.tiles });
  }
  heroInteractEnd(hero) { this.actors.endInteraction({ hero, level: this }); }

  /** backdrop: a canvas/image source or null; r: renderer; view: Rect in level coordinates */
  render(r, hero, view, backdrop) {
    if (backdrop) r.placeImage(backdrop, view.x, view.y); else r.fillRect(view, '#000');
    const sx = idiv(view.left(), W), ex = idiv(view.right(), W) + 1;
    const sy = idiv(view.top(), H), ey = idiv(view.bottom(), H) + 1;
    for (let y = sy; y < ey; y++) for (let x = sx; x < ex; x++) {
      const t = this.tiles.get(x, y);
      const n = t ? t.effective : 0;
      if (n > 1 && n < 48 * 8) r.placeTile(n, x * W, y * H);
    }
    this.actors.renderBackground(r, view);
    hero.render(r);
    this.actors.renderForeground(r, view);
    for (const s of this.shots) s.render(r);
  }

  /** one game tick */
  act(hero, cmds, msgs, playSounds, view, info) {
    const ctx = { hero, cmds, msgs, info, level: this, tiles: this.tiles };
    for (const s of this.shots) s.act(ctx);
    this.shots = this.shots.filter((s) => s.isAlive);
    const pending = msgs.splice(0, msgs.length);
    for (const m of pending) this.actors.sendMessage(m, ctx);
    hero.getsHurt = this.actors.act(ctx, view);
    // commands queued by actors become real actors now
    cmds.process(new LevelCommandProcessor(this.tiles, this.actors, playSounds, false));
    if (this.heroCanAct) hero.act(this.tiles, cmds);
    if (hero.health.life === null && this.playState.kind === 'Playing') {
      this.playState = { kind: 'KilledPlayingAnimation', n: 80 };
      cmds.addSound('PLAYERDEATH');
    }
  }

  fireShot(hero, cmds, msgs) {
    if (this.shots.length < hero.firepower.numShots() && this.heroCanAct) {
      const g = hero.position.geometry;
      const shot = new Shot(g.x, g.y, hero.direction);
      cmds.addSound('PLAYERGUN');
      shot.push({ hero, level: this, cmds, msgs }, 8 * dirFactor(shot.direction));
      this.shots.push(shot);
    }
  }
}
