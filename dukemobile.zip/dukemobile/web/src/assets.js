// SPDX-License-Identifier: AGPL-3.0-or-later
// Derived from FreeNukum tile.rs, tilecache.rs, picture.rs, backdrop.rs and
// sound.rs (c) Wolfgang Silbermayr, ported to JavaScript.
//
// All decoders are pure functions working on Uint8Array input so they can be
// tested outside of a browser.

import {
  BACKDROP_WIDTH, BACKDROP_HEIGHT, TILE_WIDTH, TILE_HEIGHT,
  PICTURE_WIDTH, PICTURE_HEIGHT, WINDOW_WIDTH, WINDOW_HEIGHT,
} from './consts.js';

// ---- tile files ---------------------------------------------------------

/** Decodes one tile of `width*8` x `height` pixels into RGBA. Returns [rgba, newOffset]. */
export function decodeTile(buf, off, width8, height, hasTransparency) {
  const width = width8 * 8;
  const out = new Uint8ClampedArray(width * height * 4);
  const loads = (width * height) / 8;
  let o = 0;
  for (let n = 0; n < loads; n++) {
    const opaqueRow = buf[off], blueRow = buf[off + 1], greenRow = buf[off + 2],
      redRow = buf[off + 3], brightRow = buf[off + 4];
    off += 5;
    for (let i = 0; i < 8; i++) {
      const sh = 7 - i;
      const bright = (brightRow >> sh) & 1, red = (redRow >> sh) & 1,
        green = (greenRow >> sh) & 1, blue = (blueRow >> sh) & 1;
      const opaque = hasTransparency ? (opaqueRow >> sh) & 1 : 1;
      const uglyYellow = red === 1 && green === 1 && blue === 0 && bright === 0 ? 1 : 0;
      out[o++] = 0x54 * (red * 2 + bright);
      out[o++] = 0x54 * (green * 2 + bright - uglyYellow);
      out[o++] = 0x54 * (blue * 2 + bright);
      out[o++] = opaque * 0xff;
    }
  }
  return [out, off, width];
}

/** Order and properties of all tile files, as in tilecache.rs. */
export const TILE_FILES = [
  [true, 'back0', 48], [false, 'back1', 48], [false, 'back2', 48], [false, 'back3', 48],
  [true, 'solid0', 48], [false, 'solid1', 48], [false, 'solid2', 48], [false, 'solid3', 48],
  [true, 'anim0', 48], [true, 'anim1', 48], [true, 'anim2', 48], [true, 'anim3', 48],
  [true, 'anim4', 48], [true, 'anim5', 48],
  [true, 'object0', 50], [true, 'object1', 50], [true, 'object2', 50],
  [true, 'man0', 48], [true, 'man1', 48], [true, 'man2', 48], [true, 'man3', 48], [true, 'man4', 48],
  [true, 'font1', 50], [true, 'font2', 50],
  [true, 'border', 48],
  [true, 'numbers', 44],
];

/** Returns an array of {w,h,data} (RGBA) for every tile, in global tile order. */
export function decodeAllTiles(getFile) {
  const tiles = [];
  for (const [transparent, name, numTiles] of TILE_FILES) {
    const buf = getFile(name);
    if (!buf) throw new Error(`Missing game file ${name}.dn1`);
    const nt = Math.min(numTiles, buf[0]);
    const w8 = buf[1], h = buf[2];
    let off = 3;
    for (let i = 0; i < nt; i++) {
      const [data, next, w] = decodeTile(buf, off, w8, h, transparent);
      off = next;
      tiles.push({ w, h, data });
    }
  }
  return tiles;
}

// ---- 320x200 pictures (title, splash screens) ---------------------------

export function decodePicture(buf) {
  const N = PICTURE_WIDTH * PICTURE_HEIGHT; // bytes per plane
  const out = new Uint8ClampedArray(WINDOW_WIDTH * WINDOW_HEIGHT * 4);
  const plane = (p, fn) => {
    for (let i = 0; i < N; i++) {
      const item = buf[p * N + i];
      for (let j = 0; j < 8; j++) fn((i * 8 + j) * 4, (item >> (7 - j)) & 1);
    }
  };
  plane(0, (o, v) => { out[o + 2] = v * 0x54 * 2; });
  plane(1, (o, v) => { out[o + 1] = v * 0x54 * 2; });
  plane(2, (o, v) => { out[o] = v * 0x54 * 2; });
  plane(3, (o, v) => {
    out[o] += v * 0x54; out[o + 1] += v * 0x54; out[o + 2] += v * 0x54; out[o + 3] = 0xff;
  });
  return { w: WINDOW_WIDTH, h: WINDOW_HEIGHT, data: out };
}

// ---- backdrops ------------------------------------------------------------

/** Backdrop: 13x10 opaque 16x16 tiles after a 3 byte header. Tolerates truncated files. */
export function decodeBackdrop(buf) {
  const W = BACKDROP_WIDTH * TILE_WIDTH, H = BACKDROP_HEIGHT * TILE_HEIGHT;
  const out = new Uint8ClampedArray(W * H * 4);
  for (let i = 3; i < out.length; i += 4) out[i] = 0xff; // opaque black
  let off = 3;
  const tileBytes = 2 * TILE_HEIGHT * 5 ;
  for (let ty = 0; ty < BACKDROP_HEIGHT; ty++) {
    for (let tx = 0; tx < BACKDROP_WIDTH; tx++) {
      if (off + tileBytes > buf.length) return { w: W, h: H, data: out, truncated: true };
      const [tile, next] = decodeTile(buf, off, 2, TILE_HEIGHT, false);
      off = next;
      for (let row = 0; row < TILE_HEIGHT; row++) {
        const dst = ((ty * TILE_HEIGHT + row) * W + tx * TILE_WIDTH) * 4;
        out.set(tile.subarray(row * TILE_WIDTH * 4, (row + 1) * TILE_WIDTH * 4), dst);
      }
    }
  }
  return { w: W, h: H, data: out, truncated: false };
}

// ---- PC speaker sounds ----------------------------------------------------

export const SAMPLE_RATE = 48000;
const BASE_FREQUENCY = 1193180.0;
const TONE_VOLUME = 3000;
const TONE_DURATION_SAMPLES = Math.floor(SAMPLE_RATE / 1000) * 11;

const framesForDivider = (d) => {
  const f = BASE_FREQUENCY / d; // Infinity for 0, like in Rust's f64 maths
  return Math.floor(Math.floor(SAMPLE_RATE / f) / 2);
};

function buildSound(words) {
  let countdown = 0, high = false, divider = 0;
  const frames = [];
  for (const d of words) {
    divider = d;
    countdown = Math.min(countdown, framesForDivider(divider));
    for (let n = 0; n < TONE_DURATION_SAMPLES; n++) {
      if (countdown === 0) {
        countdown = framesForDivider(divider);
        high = !high;
      }
      if (countdown === 0) continue; // iterator yielded None
      countdown--;
      frames.push(high ? TONE_VOLUME : -TONE_VOLUME);
    }
  }
  return Float32Array.from(frames, (v) => v / 32768);
}

/** Parses a DUKE1*.DN1 sound bank. Returns Map<NAME, Float32Array>. */
export function decodeSoundBank(raw) {
  if (!(raw[0] === 0x53 && raw[1] === 0x4e && raw[2] === 0x44 && raw[3] === 0)) {
    throw new Error('Invalid sound data');
  }
  const entries = new Map();
  let prev = null;
  for (let i = 1; i <= 24; i++) {
    const offset = 16 * i;
    const address = raw[offset] | (raw[offset + 1] << 8);
    let name = '';
    for (let k = offset + 4; k < offset + 16; k++) if (raw[k] !== 0) name += String.fromCharCode(raw[k]);
    if (prev) {
      const words = [];
      for (let p = prev.address; p + 1 < address; p += 2) words.push(raw[p] | (raw[p + 1] << 8));
      entries.set(prev.name, buildSound(words));
    }
    prev = { address, name };
  }
  return entries;
}
