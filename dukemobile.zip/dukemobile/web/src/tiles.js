// SPDX-License-Identifier: AGPL-3.0-or-later
// Derived from FreeNukum level/tiles.rs (c) Wolfgang Silbermayr, ported to JavaScript.

import { LEVEL_WIDTH, LEVEL_HEIGHT, TILE_WIDTH as W, TILE_HEIGHT as H } from './consts.js';
import { Rect, idiv } from './rect.js';

export class Tile {
  constructor(solid = false) { this.raw = 0; this.effective = 0; this.solid = solid; }
}

const posmod = (a, b) => ((a % b) + b) % b;

export class LevelTiles {
  constructor(allSolid = false) {
    this.tiles = new Array(LEVEL_WIDTH * LEVEL_HEIGHT);
    for (let i = 0; i < this.tiles.length; i++) this.tiles[i] = new Tile(allSolid);
  }
  isInRange(x, y) { return x >= 0 && x < LEVEL_WIDTH && y >= 0 && y < LEVEL_HEIGHT; }
  /** Returns the Tile or null when out of range (the Err case in Rust). */
  get(x, y) { return this.isInRange(x, y) ? this.tiles[y * LEVEL_WIDTH + x] : null; }
  /** solid state with a default for out-of-range access, mirroring `.map(|t| t.solid).unwrap_or(d)` */
  solidAt(x, y, dflt) { const t = this.get(x, y); return t ? t.solid : dflt; }
  copyEffectiveNumber(xf, yf, xt, yt) {
    const a = this.get(xf, yf), b = this.get(xt, yt);
    if (!a || !b) throw new Error('Can\'t copy effective number');
    b.effective = a.effective;
  }

  collides(rect) {
    if (rect.left() < 0 || rect.top() < 0 ||
        rect.right() >= LEVEL_WIDTH * W || rect.bottom() >= LEVEL_HEIGHT * H) return true;
    const solidrect = new Rect(0, 0, W, H);
    const left = idiv(rect.left(), W), right = idiv(rect.right(), W) + 1;
    const top = idiv(rect.top(), H), bottom = idiv(rect.bottom(), H) + 1;
    for (let i = left; i < right; i++) {
      for (let j = top; j < bottom; j++) {
        if (this.solidAt(i, j, true)) {
          solidrect.x = i * W; solidrect.y = j * H;
          if (rect.hasIntersection(solidrect)) return true;
        }
      }
    }
    return false;
  }

  // NOTE: the return values deliberately mirror FreeNukum, including the fact
  // that on a partial move the returned offset is not the distance moved.
  pushRectVertically(geometry, offset) {
    if (offset === 0) return 0;
    geometry.y += offset;
    if (!this.collides(geometry)) return offset;
    const abs = Math.abs(offset), direction = Math.sign(offset);
    for (let i = 0; i < abs; i++) {
      geometry.offset(0, -direction);
      if (!this.collides(geometry)) return i * direction;
    }
    return 0;
  }

  pushRectHorizontally(geometry, offset) {
    if (offset === 0) return 0;
    geometry.x += offset;
    if (!this.collides(geometry)) return offset;
    const abs = Math.abs(offset), direction = Math.sign(offset);
    for (let i = 0; i < abs; i++) {
      geometry.offset(-direction, 0);
      if (!this.collides(geometry)) return i * direction;
    }
    return 0;
  }

  pushRectStandingOnGround(rect, offset, gravity) {
    if (this.collides(rect)) return false; // locked in
    this.rectFallDown(rect, gravity);
    const stoodSolid = this.rectStandsOnGroundCompletely(rect);
    rect.offset(offset, 0);
    if (this.collides(rect)) { rect.offset(-offset, 0); return false; }
    if (stoodSolid && this.rectStandsOnGroundCompletely(rect)) return true;
    if (stoodSolid) { rect.offset(-offset, 0); return false; }
    return true;
  }

  rectFallDown(rect, distance) {
    if (this.collides(rect)) return 0;
    if (this.rectStandsOnGroundPartially(rect)) return 0;
    for (let i = 0; i < distance; i++) {
      rect.y += 1;
      if (this.rectStandsOnGroundPartially(rect)) return i;
    }
    return distance;
  }

  rectStandsOnGroundPartially(rect) {
    if (posmod(rect.bottom(), H) > 0) return false;
    const j = idiv(rect.bottom(), H);
    for (let i = idiv(rect.left(), W); i < 1 + idiv(rect.right(), W); i++) {
      if (this.solidAt(i, j, true)) {
        const tl = i * W, tr = tl + W;
        if ((tl < rect.right() && tr >= rect.right()) || (tl <= rect.left() && tr > rect.left())) return true;
      }
    }
    return false;
  }

  rectStandsOnGroundCompletely(rect) {
    if (rect.bottom() % H > 0) return false;
    const j = idiv(rect.bottom(), H);
    for (let i = idiv(rect.left(), W); i < idiv(rect.right() + 1, W) + 1; i++) {
      if (!this.solidAt(i, j, true)) return false;
    }
    return true;
  }
}
