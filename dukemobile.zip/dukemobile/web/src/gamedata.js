// SPDX-License-Identifier: AGPL-3.0-or-later
// Holds the user-supplied game files (never bundled) and decodes them on demand.
import { decodeAllTiles, decodePicture, decodeBackdrop, decodeSoundBank, TILE_FILES } from './assets.js';
import { parseStrings, Strings } from './strings.js';

const REQUIRED = [...TILE_FILES.map(([, n]) => n.toUpperCase() + '.DN1'), 'WORLDAL1.DN1', 'WORLDAL2.DN1', 'DUKE1.DN1'];

export class GameData {
  /** @param {Map<string,Uint8Array>} files upper-case basename -> bytes */
  constructor(files) {
    this.files = files;
    this.strings = new Strings();
    if (files.has('STRINGS.TXT')) this.strings = new Strings(parseStrings(new TextDecoder('latin1').decode(files.get('STRINGS.TXT'))));
  }
  static missing(files) { return REQUIRED.filter((n) => !files.has(n)); }
  has(name) { return this.files.has(name.toUpperCase()); }
  get(name) { return this.files.get(name.toUpperCase()) ?? null; }

  tiles() { return decodeAllTiles((n) => this.get(n + '.DN1')); }
  picture(name) { const b = this.get(name + '.DN1'); return b ? decodePicture(b) : null; }
  backdrop(n) { const b = this.get(`DROP${n}.DN1`); return b ? decodeBackdrop(b) : null; }
  level(fileHex) { return this.get(`WORLDAL${fileHex}.DN1`); }
  sounds() {
    const bank = new Map();
    for (const f of ['DUKE1.DN1', 'DUKE1-B.DN1']) {
      const b = this.get(f);
      if (b) for (const [k, v] of decodeSoundBank(b)) bank.set(k, v);
    }
    return bank;
  }
  /** Level number (1-based, 1..11) -> world file hex digit, mirroring FreeNukum's level_filenumber. */
  static levelFileHex(levelNumber, interlevel) {
    const n = interlevel ? 2 : levelNumber === 1 ? 1 : levelNumber + 1;
    return n.toString(16).toUpperCase();
  }
  /** Backdrop number for a level, using the level/backdrop tables of the original executable when
   *  STRINGS.TXT is present, FreeNukum's table otherwise. */
  backdropNumber(levelNumber) {
    if (this.strings.has('BACKDROPS')) {
      const list = this.strings.get('BACKDROPS');
      const idx = (levelNumber - 1) * 2;
      const m = /drop(\d+)/i.exec(list[idx] ?? '');
      if (m) return Number(m[1]);
    }
    return { 1: 0, 2: 0, 3: 7, 4: 3, 5: 2, 6: 1, 7: 3, 8: 5, 9: 1 }[levelNumber] ?? 1;
  }
}
