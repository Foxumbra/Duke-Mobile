// SPDX-License-Identifier: AGPL-3.0-or-later
// IndexedDB persistence for the user's imported game files (kept on the device only).
const DB = 'dukemobile', STORE = 'files';

function open() {
  return new Promise((res, rej) => {
    const rq = indexedDB.open(DB, 1);
    rq.onupgradeneeded = () => rq.result.createObjectStore(STORE);
    rq.onsuccess = () => res(rq.result);
    rq.onerror = () => rej(rq.error);
  });
}
const tx = (db, mode) => db.transaction(STORE, mode).objectStore(STORE);
const wrap = (rq) => new Promise((res, rej) => { rq.onsuccess = () => res(rq.result); rq.onerror = () => rej(rq.error); });

export async function saveFiles(map) {
  const db = await open();
  await wrap(tx(db, 'readwrite').clear());
  const t = db.transaction(STORE, 'readwrite');
  const st = t.objectStore(STORE);
  for (const [k, v] of map) st.put(v, k);
  await new Promise((res, rej) => { t.oncomplete = res; t.onerror = () => rej(t.error); });
  db.close();
}

export async function loadFiles() {
  try {
    const db = await open();
    const st = tx(db, 'readonly');
    const keys = await wrap(st.getAllKeys());
    const vals = await wrap(tx(db, 'readonly').getAll());
    db.close();
    const m = new Map();
    keys.forEach((k, i) => m.set(k, vals[i] instanceof Uint8Array ? vals[i] : new Uint8Array(vals[i])));
    return m;
  } catch { return new Map(); }
}

export async function clearFiles() {
  const db = await open();
  await wrap(tx(db, 'readwrite').clear());
  db.close();
}
