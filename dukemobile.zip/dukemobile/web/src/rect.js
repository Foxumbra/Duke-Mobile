// SPDX-License-Identifier: AGPL-3.0-or-later
// Derived from FreeNukum (c) Wolfgang Silbermayr, ported to JavaScript.
//
// Rect mirrors the semantics of sdl2::rect::Rect that FreeNukum relies on:
// edges are exclusive (right = x + w, bottom = y + h) and an intersection
// needs a strictly positive overlap area.

export const idiv = (a, b) => Math.trunc(a / b);

export class Point {
  constructor(x, y) { this.x = x; this.y = y; }
  offset(dx, dy) { return new Point(this.x + dx, this.y + dy); }
}

export class Rect {
  constructor(x, y, w, h) {
    this.x = x; this.y = y; this.w = Math.max(0, w); this.h = Math.max(0, h);
  }
  topRight() { return new Point(this.x + this.w, this.y); }
  resize(w, h) { this.w = w; this.h = h; }
  clone() { return new Rect(this.x, this.y, this.w, this.h); }
  left() { return this.x; }
  right() { return this.x + this.w; }
  top() { return this.y; }
  bottom() { return this.y + this.h; }
  topLeft() { return new Point(this.x, this.y); }
  center() { return new Point(this.x + idiv(this.w, 2), this.y + idiv(this.h, 2)); }
  offset(dx, dy) { this.x += dx; this.y += dy; }
  setWidth(w) { this.w = Math.max(0, w); }
  setHeight(h) { this.h = Math.max(0, h); }
  setRight(r) { this.x = r - this.w; }
  setBottom(b) { this.y = b - this.h; }
  hasIntersection(o) {
    if (this.w <= 0 || this.h <= 0 || o.w <= 0 || o.h <= 0) return false;
    const l = Math.max(this.x, o.x), r = Math.min(this.x + this.w, o.x + o.w);
    if (r <= l) return false;
    const t = Math.max(this.y, o.y), b = Math.min(this.y + this.h, o.y + o.h);
    return b > t;
  }
  // RectExt from geometry.rs
  touches(o) {
    const r1 = new Rect(this.x, this.y, this.w + 1, this.h + 1);
    const r2 = new Rect(o.x, o.y, o.w + 1, o.h + 1);
    return r1.hasIntersection(r2);
  }
  overlapsVertically(o) {
    if (this.y + this.h <= o.y) return false;
    if (o.y + o.h <= this.y) return false;
    return true;
  }
  horizontalDistance(o) {
    if (this.right() < o.left()) return this.right() - o.left();
    if (o.right() < this.left()) return this.left() - o.right();
    return 0;
  }
}

// Port of RangedIterator from lib.rs
export class RangedIterator {
  constructor(max) { this.current = 0; this.max = max; this.finishedCycles = 0; }
  reset(max) { this.current = 0; this.max = max; this.finishedCycles = 0; }
  isFirst() { return this.current === 0; }
  currentReverse() { return this.max - 1 - this.current; }
  maxValue() { return this.max; }
  next() {
    this.current += 1;
    const old = this.current;
    this.current %= this.max;
    if (this.current !== old) this.finishedCycles = (this.finishedCycles + 1) >>> 0;
    return this.current;
  }
  rewind() {
    if (this.current === 0) {
      this.current = this.max;
      if (this.current > 0) this.current -= 1;
      if (this.finishedCycles > 0) this.finishedCycles -= 1;
      else this.finishedCycles = 0xffffffff;
    } else this.current -= 1;
  }
}

export const Dir = Object.freeze({ Left: 'L', Right: 'R' });
export const dirFactor = (d) => (d === Dir.Left ? -1 : 1);
export const dirOpposite = (d) => (d === Dir.Left ? Dir.Right : Dir.Left);
export const dirMap = (d, l, r) => (d === Dir.Left ? l : r);
