// SPDX-License-Identifier: AGPL-3.0-or-later
// EXPERIMENTAL / UNTESTED against real archives (no imploded sample was available).
// PKWARE DCL "implode" decompressor (ZIP method 6), written from the APPNOTE description.
// Flags: bit 1 => 8K dictionary (else 4K); bit 2 => 3 Shannon-Fano trees (literals coded), else 2 trees.

const LEN_BASE = [2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 16, 24, 40, 72, 136, 264];
const LEN_EXTRA = [0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8];

class BitReader {
  constructor(buf) { this.buf = buf; this.pos = 0; this.bit = 0; this.cur = 0; }
  // bits are consumed LSB first
  bits(n) {
    let v = 0;
    for (let i = 0; i < n; i++) {
      if (this.bit === 0) { if (this.pos >= this.buf.length) throw new Error('implode: out of data'); this.cur = this.buf[this.pos++]; this.bit = 8; }
      v |= (this.cur & 1) << i; this.cur >>= 1; this.bit -= 1;
    }
    return v;
  }
}

/** Reads a Shannon-Fano tree description and returns a decoder map built from code lengths. */
function readTree(br, n) {
  const entries = br.bits(8) + 1;
  const lengths = new Array(n).fill(0);
  let sym = 0;
  for (let i = 0; i < entries; i++) {
    const b = br.bits(8);
    const len = (b & 15) + 1, reps = (b >> 4) + 1;
    for (let r = 0; r < reps; r++) lengths[sym++] = len;
  }
  // canonical assignment: sort by (length desc?) -- PKWARE codes are assigned from the longest
  // length, symbols ascending within a length, and are read bit-inverted.
  const order = [];
  for (let s = 0; s < n; s++) if (lengths[s] > 0) order.push(s);
  order.sort((a, b2) => lengths[b2] - lengths[a] || a - b2);
  const table = new Map();
  let code = 0, prevLen = lengths[order[0]];
  for (const s of order) {
    const len = lengths[s];
    if (len !== prevLen) { code >>= (prevLen - len); prevLen = len; }
    table.set(len + ':' + code, s);
    code += 1;
  }
  const maxLen = Math.max(...lengths);
  return { table, maxLen };
}

function decode(br, tree) {
  let code = 0;
  for (let len = 1; len <= tree.maxLen; len++) {
    // first bit read is the most significant of the code, stored inverted
    code = (code << 1) | (br.bits(1) ^ 1);
    const s = tree.table.get(len + ':' + code);
    if (s !== undefined) return s;
  }
  throw new Error('implode: bad code');
}

export function explode(src, outSize, flags) {
  const literals = (flags & 4) !== 0;
  const dictBits = (flags & 2) !== 0 ? 7 : 6;
  const br = new BitReader(src);
  const litTree = literals ? readTree(br, 256) : null;
  const lenTree = readTree(br, 64);
  const distTree = readTree(br, 64);
  const out = new Uint8Array(outSize);
  let o = 0;
  while (o < outSize) {
    if (br.bits(1)) {
      let d = br.bits(dictBits);
      d |= decode(br, distTree) << dictBits;
      const slot = decode(br, lenTree);
      const len = LEN_BASE[slot] + br.bits(LEN_EXTRA[slot]);
      d += 1;
      for (let i = 0; i < len && o < outSize; i++, o++) out[o] = out[o - d];
    } else {
      out[o++] = literals ? decode(br, litTree) : br.bits(8);
    }
  }
  return out;
}
