// SPDX-License-Identifier: AGPL-3.0-or-later
// Unified keyboard / touch / gamepad input. Game code listens to named events.

export class Input {
  constructor() {
    this.handlers = new Map();
    this.held = new Set();       // currently held logical buttons
    this.waiters = [];           // pending one-shot "confirm" promises
    this.pointerTap = null;      // optional (x,y) tap handler for menus
  }
  /** Handlers form a stack per event name: the newest one receives events until `off` pops it. */
  on(name, fn) { if (!this.handlers.has(name)) this.handlers.set(name, []); this.handlers.get(name).push(fn); }
  off(name) { const a = this.handlers.get(name); if (a) a.pop(); }
  emit(name, arg) { const a = this.handlers.get(name); if (a && a.length) a[a.length - 1](arg); }

  /** Logical button press/release: left,right,jump,fire,use,menu,confirm */
  press(btn) {
    if (this.held.has(btn)) return;
    this.held.add(btn);
    this.emit('press', btn);
    if (btn === 'confirm' || btn === 'jump' || btn === 'fire' || btn === 'use') this.resolveWaiters(btn);
  }
  release(btn) {
    if (!this.held.delete(btn)) return;
    this.emit('release', btn);
  }
  isHeld(btn) { return this.held.has(btn); }

  resolveWaiters(btn) {
    const w = this.waiters; this.waiters = [];
    for (const fn of w) fn(btn);
  }
  /** Resolves on the next confirm-ish press (Enter, tap anywhere, any action button). */
  waitConfirm() { return new Promise((res) => this.waiters.push(res)); }

  attachKeyboard(target = window) {
    const map = {
      ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'use', KeyW: 'use', KeyA: 'left', KeyD: 'right',
      ControlLeft: 'jump', ControlRight: 'jump', Space: 'jump', KeyZ: 'jump',
      AltLeft: 'fire', AltRight: 'fire', KeyX: 'fire', ShiftLeft: 'fire', ShiftRight: 'fire',
      Escape: 'menu', F1: 'menu', Enter: 'confirm', NumpadEnter: 'confirm',
    };
    target.addEventListener('keydown', (e) => {
      const b = map[e.code];
      if (!e.repeat) this.emit('anykey', e);
      if (b) { e.preventDefault(); if (!e.repeat) this.press(b); }
      else if (!e.repeat) this.resolveWaiters('key');
    });
    target.addEventListener('keyup', (e) => { const b = map[e.code]; if (b) { e.preventDefault(); this.release(b); } });
    target.addEventListener('blur', () => { for (const b of [...this.held]) this.release(b); });
  }

  /** Wire on-screen buttons: elements with data-btn="left|right|jump|fire|use|menu". */
  attachTouch(root) {
    root.querySelectorAll('[data-btn]').forEach((el) => {
      const btn = el.dataset.btn;
      const down = (e) => { e.preventDefault(); el.setPointerCapture?.(e.pointerId); el.classList.add('down'); this.press(btn); };
      const up = (e) => { e.preventDefault(); el.classList.remove('down'); this.release(btn); };
      el.addEventListener('pointerdown', down);
      el.addEventListener('pointerup', up);
      el.addEventListener('pointercancel', up);
      el.addEventListener('lostpointercapture', up);
      el.addEventListener('contextmenu', (e) => e.preventDefault());
    });
  }

  /** Gamepad polling; call once per frame. */
  pollGamepad() {
    const pads = navigator.getGamepads ? navigator.getGamepads() : [];
    const pad = [...pads].find((p) => p && p.connected);
    const want = new Set();
    if (pad) {
      const ax = pad.axes[0] || 0, ay = pad.axes[1] || 0, b = pad.buttons;
      if (ax < -0.5 || b[14]?.pressed) want.add('left');
      if (ax > 0.5 || b[15]?.pressed) want.add('right');
      if (ay < -0.5 || b[12]?.pressed) want.add('use');
      if (b[0]?.pressed) want.add('jump');
      if (b[2]?.pressed || b[1]?.pressed) want.add('fire');
      if (b[9]?.pressed) want.add('menu');
    }
    for (const g of ['left', 'right', 'use', 'jump', 'fire', 'menu']) {
      const key = 'pad:' + g;
      if (want.has(g)) { if (!this.held.has(key)) { this.held.add(key); this.press(g); } }
      else if (this.held.has(key)) { this.held.delete(key); this.release(g); }
    }
  }
}
