// SPDX-License-Identifier: AGPL-3.0-or-later
// Canvas renderer for 320x200 game graphics (tiles are pre-rendered to small canvases).
import { FONT_ASCII_UPPERCASE, FONT_ASCII_LOWERCASE, FONT_QUESTIONMARK, FONT_WIDTH, FONT_HEIGHT } from './consts.js';

function toCanvas(w, h, data) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  c.getContext('2d').putImageData(new ImageData(data, w, h), 0, 0);
  return c;
}

export class Renderer {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false });
    this.ctx.imageSmoothingEnabled = false;
    this.tiles = [];
    this.ox = 0; this.oy = 0;
  }
  setTiles(decoded) { this.tiles = decoded.map((t) => toCanvas(t.w, t.h, t.data)); }
  /** Convert a decoded {w,h,data} image into a drawable canvas. */
  makeImage(img) { return toCanvas(img.w, img.h, img.data); }

  placeTile(n, x, y) {
    const t = this.tiles[n];
    if (t) this.ctx.drawImage(t, x + this.ox, y + this.oy);
  }
  placeImage(img, x, y) { this.ctx.drawImage(img, x + this.ox, y + this.oy); }
  fillRect(rect, color) {
    this.ctx.fillStyle = color;
    this.ctx.fillRect(rect.x + this.ox, rect.y + this.oy, rect.w, rect.h);
  }
  clear(color = '#000') { this.ctx.fillStyle = color; this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height); }
  clip(x, y, w, h) { this.ctx.save(); this.ctx.beginPath(); this.ctx.rect(x, y, w, h); this.ctx.clip(); }
  unclip() { this.ctx.restore(); }

  /** Draws text using the game's 8x8 font. Returns nothing. */
  text(str, x, y) {
    let ox = 0, oy = 0;
    for (const c of str) {
      if (c === '\n') { ox = 0; oy += FONT_HEIGHT; continue; }
      let n;
      if (c >= ' ' && c <= 'Z') n = c.charCodeAt(0) - 32 + FONT_ASCII_UPPERCASE;
      else if (c >= 'a' && c <= 'z') n = c.charCodeAt(0) - 97 + FONT_ASCII_LOWERCASE;
      else n = FONT_QUESTIONMARK;
      this.placeTile(n, x + ox, y + oy);
      ox += FONT_WIDTH;
    }
  }
}
export { FONT_WIDTH, FONT_HEIGHT };
