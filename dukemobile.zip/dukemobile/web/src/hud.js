// SPDX-License-Identifier: AGPL-3.0-or-later
// Derived from FreeNukum borders.rs / messagebox.rs (c) Wolfgang Silbermayr, ported to JavaScript.
import {
  BORDER_GREY_START, MAX_LIFE, OBJECT_HEALTH, OBJECT_NONHEALTH, OBJECT_GUN, OBJECT_SHOT, OBJECT_KEY_RED,
  OBJECT_KEY_GREEN, OBJECT_KEY_BLUE, OBJECT_KEY_PINK, OBJECT_BOOT, OBJECT_GLOVE, OBJECT_CLAMP,
  OBJECT_ACCESS_CARD, BORDER_BLUE_MIDDLE, BORDER_BLUE_TOPLEFT, BORDER_BLUE_TOPRIGHT,
  BORDER_BLUE_BOTTOMLEFT, BORDER_BLUE_BOTTOMRIGHT, BORDER_BLUE_LEFT, BORDER_BLUE_RIGHT, BORDER_BLUE_TOP,
  BORDER_BLUE_BOTTOM, FONT_WIDTH, FONT_HEIGHT, KeyColor,
} from './consts.js';
import { Item } from './hero.js';
import { BORDERS } from './bordersdata.js';

export function renderBorders(r) {
  for (let i = 0; i < BORDERS.length; i++) {
    const n = BORDERS[i];
    if (n >= 0) r.placeTile(n + BORDER_GREY_START, (i % 40) * 8, Math.floor(i / 40) * 8);
  }
}

export function renderLife(r, health) {
  const h = Math.min(health, MAX_LIFE);
  for (let i = 0; i < MAX_LIFE; i++) r.placeTile(i < h ? OBJECT_HEALTH : OBJECT_NONHEALTH, 240 + i * 8, 60);
}

export function renderScore(r, score) {
  const s = String(Math.min(99999999, score)).padStart(8, '0');
  r.text(s, 30 * FONT_WIDTH, 3 * FONT_HEIGHT);
}

export function renderFirepower(r, firepower) {
  const shots = firepower.numShots(), ox = 240, oy = 96;
  r.placeTile(OBJECT_GUN, ox + 3 * 8, oy);
  for (let k = 0; k < 4; k++) if (shots > k) r.placeTile(OBJECT_SHOT, ox + k * 16, oy + 16);
}

export function renderInventory(r, inv) {
  const tiles = [
    inv.isSet(Item.Key(KeyColor.Red)) ? OBJECT_KEY_RED : null,
    inv.isSet(Item.Key(KeyColor.Green)) ? OBJECT_KEY_GREEN : null,
    inv.isSet(Item.Key(KeyColor.Blue)) ? OBJECT_KEY_BLUE : null,
    inv.isSet(Item.Key(KeyColor.Pink)) ? OBJECT_KEY_PINK : null,
    inv.isSet(Item.Boot) ? OBJECT_BOOT : null,
    inv.isSet(Item.Glove) ? OBJECT_GLOVE : null,
    inv.isSet(Item.Clamp) ? OBJECT_CLAMP : null,
    inv.isSet(Item.AccessCard) ? OBJECT_ACCESS_CARD : null,
  ];
  tiles.forEach((t, i) => { if (t !== null) r.placeTile(t, 240 + (i % 4) * 16, 144 + Math.floor(i / 4) * 16); });
}

export function renderHud(r, hero) {
  renderBorders(r);
  renderLife(r, hero.health.life ?? 0);
  renderFirepower(r, hero.firepower);
  renderInventory(r, hero.inventory);
  renderScore(r, hero.score.value());
}

/** Draws a blue-bordered message box with the given text at (x, y). Returns its pixel size. */
export function drawMessageBox(r, text, x, y) {
  const lines = text.split('\n');
  const cols = Math.max(...lines.map((l) => l.length)), rows = lines.length;
  for (let row = 0; row <= rows; row++) {
    for (let col = 0; col <= cols; col++) {
      let n;
      if (row === 0 && col === 0) n = BORDER_BLUE_TOPLEFT;
      else if (row === 0 && col === cols) n = BORDER_BLUE_TOPRIGHT;
      else if (row === rows && col === 0) n = BORDER_BLUE_BOTTOMLEFT;
      else if (row === rows && col === cols) n = BORDER_BLUE_BOTTOMRIGHT;
      else if (row === 0) n = BORDER_BLUE_TOP;
      else if (col === 0) n = BORDER_BLUE_LEFT;
      else if (row === rows) n = BORDER_BLUE_BOTTOM;
      else if (col === cols) n = BORDER_BLUE_RIGHT;
      else n = BORDER_BLUE_MIDDLE;
      r.placeTile(n, x + col * FONT_WIDTH, y + row * FONT_HEIGHT);
    }
  }
  r.text(text, x + FONT_WIDTH, y + FONT_HEIGHT);
  return { w: FONT_WIDTH * (cols + 2), h: FONT_HEIGHT * (rows + 2) };
}

export function messageBoxSize(text) {
  const lines = text.split('\n');
  return { w: FONT_WIDTH * (Math.max(...lines.map((l) => l.length)) + 2), h: FONT_HEIGHT * (lines.length + 2) };
}
