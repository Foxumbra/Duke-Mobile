// SPDX-License-Identifier: AGPL-3.0-or-later
import { Renderer } from './renderer.js';
import { Input } from './input.js';
import { SoundPlayer } from './sound.js';
import { Game } from './game.js';
import { GameData } from './gamedata.js';
import { readZip } from './zip.js';
import { loadFiles, saveFiles, clearFiles } from './store.js';

const $ = (id) => document.getElementById(id);
const canvas = $('screen'), controls = $('controls'), importPanel = $('import');
const status = $('importstatus');

const input = new Input();
input.attachKeyboard();
input.attachTouch(controls);
const sound = new SoundPlayer();
const renderer = new Renderer(canvas);
const game = new Game({ renderer, input, sound });
window.__game = game; // handy for debugging / automated tests

function say(msg, err = false) { status.textContent = msg; status.className = err ? 'err' : ''; }

canvas.addEventListener('pointerdown', (e) => {
  sound.unlock();
  const rect = canvas.getBoundingClientRect();
  game.tap(((e.clientX - rect.left) / rect.width) * 320, ((e.clientY - rect.top) / rect.height) * 200);
});
window.addEventListener('pointerdown', () => sound.unlock(), { once: false });

async function keepAwake() {
  try { if ('wakeLock' in navigator) await navigator.wakeLock.request('screen'); } catch { /* optional */ }
}
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') keepAwake(); else sound.stopAll(); });

async function collect(fileList) {
  const files = new Map();
  for (const f of fileList) {
    const buf = new Uint8Array(await f.arrayBuffer());
    if (/\.zip$/i.test(f.name)) {
      for (const [k, v] of await readZip(buf)) files.set(k, v);
    } else {
      let name = f.name.split(/[\\/]/).pop().toUpperCase();
      if (name.endsWith('STRINGS.TXT')) name = 'STRINGS.TXT';
      files.set(name, buf);
    }
  }
  return files;
}

async function begin(files) {
  const missing = GameData.missing(files);
  if (missing.length) {
    say(`These game files are missing:\n${missing.slice(0, 12).join(', ')}${missing.length > 12 ? ', …' : ''}\n\nUse the ZIP of Duke Nukem 1 (Episode 1) or select all of its .DN1 files.`, true);
    importPanel.hidden = false;
    return false;
  }
  game.setData(new GameData(files));
  importPanel.hidden = true;
  controls.hidden = false;
  keepAwake();
  await game.mainMenu();
  if (game.quitRequested) {
    if (window.AndroidBridge?.exit) window.AndroidBridge.exit(); else { controls.hidden = true; importPanel.hidden = false; $('clearbtn').hidden = false; say('Game closed. Reload to play again.'); }
  }
  return true;
}

$('zipinput').addEventListener('change', async (e) => {
  try {
    say('Reading files…');
    const files = await collect(e.target.files);
    if (await begin(files)) await saveFiles(files).catch(() => {});
  } catch (err) { say('Could not read the files: ' + err.message, true); }
  e.target.value = '';
});
$('clearbtn').addEventListener('click', async () => { await clearFiles(); $('clearbtn').hidden = true; say('Stored game files removed.'); });

(async () => {
  const stored = await loadFiles();
  if (stored.size && !GameData.missing(stored).length) { $('clearbtn').hidden = false; await begin(stored); }
})();
