// SPDX-License-Identifier: AGPL-3.0-or-later
// Derived from FreeNukum actor/{conveyor,elevator,fan,fire,mill,electricarc}.rs (c) Wolfgang Silbermayr.
import {
  SOLID_CONVEYORBELT_LEFTEND, SOLID_CONVEYORBELT_CENTER, SOLID_CONVEYORBELT_RIGHTEND, SOLID_BLACK,
  SOLID_ELEVATOR, OBJECT_ELEVATOR_TOP, ANIMATION_FAN, OBJECT_FIRERIGHT, OBJECT_FIRELEFT,
  OBJECT_ROTATINGCYLINDER, OBJECT_ELECTRIC_ARC, OBJECT_ELECTRIC_ARC_HURTING,
  TILE_WIDTH as W, TILE_HEIGHT as H, HALFTILE_WIDTH as HW,
} from '../consts.js';
import { Rect, RangedIterator, idiv, Dir, dirFactor } from '../rect.js';
import { Actor, BG, Absorb, T } from './base.js';

export class Conveyor extends Actor {
  /** Created for the RIGHT end of the belt; scans left for its beginning, widening the rect. */
  constructor(x, y, { dir }, tiles) {
    super(x, y);
    this.dir = dir; this.frame = new RangedIterator(4);
    let found = false;
    while (!found) {
      this.position.offset(-W, 0);
      this.position.setWidth(this.position.w + W);
      const t = tiles.get(idiv(this.position.x, W), idiv(this.position.y, H));
      if (t) {
        if (t.effective === SOLID_CONVEYORBELT_LEFTEND || this.position.x <= 0 || t.effective === 0) {
          found = true; t.effective = SOLID_BLACK;
        }
      } else found = true;
    }
  }
  act(p) {
    this.frame.next();
    const push = this.dir === Dir.Left ? -HW : HW;
    const g = p.hero.position.geometry;
    if (g.right() > this.position.left() && g.left() < this.position.right() && g.bottom() === this.position.top()) {
      p.hero.position.pushHorizontally(p.tiles, push);
    }
  }
  render(r) {
    const off = this.dir === Dir.Left ? this.frame.currentReverse() : this.frame.current;
    let tile = SOLID_CONVEYORBELT_LEFTEND + off;
    let x = this.position.x;
    const n = idiv(this.position.w, W);
    for (let i = 0; i < n; i++) {
      if (i === n - 1) tile = SOLID_CONVEYORBELT_RIGHTEND + off;
      else if (i === 1) tile = SOLID_CONVEYORBELT_CENTER + (off % 2);
      r.placeTile(tile, x, this.position.y);
      x += W;
    }
  }
}

export class Elevator extends Actor {
  constructor(x, y) { super(x, y); this.state = 'Idle'; }
  act(p) {
    const g = p.hero.position.geometry;
    if (this.state === 'Ascending' || (this.state === 'Idle' && this.position.h > H)) {
      if (!g.touches(this.position) || this.position.x !== g.x) this.state = 'Descending';
    }
    if (this.state === 'Ascending') {
      const head = p.tiles.get(idiv(this.position.x, W), idiv(this.position.y, H) - 3);
      if (head === null || head.solid) this.state = 'Idle';
      else {
        p.cmds.addSound('ELEVATOR');
        const offset = p.hero.position.pushVertically(p.tiles, -H);
        if (-offset < H) {
          p.hero.position.pushVertically(p.tiles, -offset);
          this.state = 'Idle';
        } else {
          this.position.offset(0, offset);
          this.position.setHeight(this.position.h + -offset);
          const t = p.tiles.get(idiv(this.position.x, W), idiv(this.position.y, H));
          if (t) t.solid = true;
        }
      }
    } else if (this.state === 'Descending') {
      for (let i = 0; i < 2; i++) {
        if (this.position.h > H) {
          const t = p.tiles.get(idiv(this.position.x, W), idiv(this.position.y, H));
          if (t) t.solid = false;
          this.position.offset(0, H);
          this.position.setHeight(this.position.h - H);
        } else this.state = 'Idle';
      }
    }
  }
  heroCanInteract(hero) { return this.position.x === hero.position.geometry.x; }
  heroInteractStart(p) {
    const g = p.hero.position.geometry;
    if (g.touches(this.position) && g.bottom() === this.position.top()) this.state = 'Ascending';
  }
  heroInteractEnd(p) {
    const g = p.hero.position.geometry;
    this.state = g.touches(this.position) && g.x === this.position.x ? 'Idle' : 'Descending';
  }
  render(r) {
    const n = (idiv(this.position.h, H) - 1) * 2;
    let y = this.position.y;
    for (let i = 0; i < n; i++) { y += H / 2; r.placeTile(SOLID_ELEVATOR, this.position.x, y); }
    r.placeTile(OBJECT_ELEVATOR_TOP, this.position.x, this.position.y);
  }
  actsWhileInvisible() { return true; }
}

export class Fan extends Actor {
  constructor(x, y, { dir }) {
    super(x, y - H, W, H * 2);
    this.dir = dir; this.tile = ANIMATION_FAN; this.frame = new RangedIterator(4); this.running = 10;
  }
  act(p) {
    if ([1, 5, 8, 10].includes(this.running)) this.frame.next();
    if (this.running < 10 && this.running > 0) this.running -= 1;
    else if (this.running === 10 && p.hero.position.geometry.overlapsVertically(this.position)) {
      let hd = p.hero.position.geometry.horizontalDistance(this.position);
      const fd = dirFactor(this.dir);
      if (fd * hd < 0) return;
      if (hd === 0) hd = HW * fd;
      if (Math.abs(hd) < HW * 8) p.hero.position.pushHorizontally(p.tiles, fd * W);
    }
  }
  render(r) {
    const base = this.tile + this.frame.current * 2;
    r.placeTile(base, this.position.x, this.position.y);
    r.placeTile(base + 1, this.position.x, this.position.y + H);
  }
  canGetShot() { return true; }
  shot(p) {
    this.running = 9;
    p.cmds.addActor(T('SingleAnimation', { a: 'Steam' }), this.position.topLeft().offset(0, -idiv(H, 2)));
    return Absorb;
  }
  isInForeground() { return true; }
  backgroundTileStrategy() { return BG.CopyFromAbove; }
}

const CYCLES_OFF = 20, CYCLES_IGNITION = 10, CYCLES_BURNING = 10, ANIM_LEN = 2;

export class Fire extends Actor {
  constructor(x, y, { dir }) {
    super(dir === Dir.Right ? x : x - 2 * W, y);
    this.dir = dir; this.tile = dir === Dir.Right ? OBJECT_FIRERIGHT : OBJECT_FIRELEFT;
    this.state = 'Off'; this.frame = new RangedIterator(ANIM_LEN);
  }
  act(p) {
    if (this.state === 'Off') {
      if (this.frame.finishedCycles === CYCLES_OFF) { this.frame.reset(ANIM_LEN); this.state = 'Ignition'; p.cmds.addSound('TORCHON'); }
    } else if (this.state === 'Ignition') {
      if (this.frame.finishedCycles === CYCLES_IGNITION) { this.frame.reset(ANIM_LEN); this.state = 'Burning'; }
    } else if (this.frame.finishedCycles === CYCLES_BURNING) { this.frame.reset(ANIM_LEN); this.state = 'Off'; }
    this.frame.next();
  }
  render(r) {
    const o = this.frame.current, L = this.dir === Dir.Left, t = this.tile;
    let tiles = [null, null, null];
    if (this.state === 'Ignition') { if (o > 0) tiles = L ? [null, null, t] : [t, null, null]; }
    else if (this.state === 'Burning') tiles = L ? [t + 3 + o, t + 1 + o, t + 1 + o] : [t + 1 + o, t + 1 + o, t + 3 + o];
    tiles.forEach((tile, i) => { if (tile !== null) r.placeTile(tile, this.position.x + i * W, this.position.y); });
  }
  isInForeground() { return true; }
  hurtsHero(hero) { return this.state === 'Burning' && this.position.hasIntersection(hero.position.geometry); }
  backgroundTileStrategy() { return this.dir === Dir.Right ? BG.CopyFromRight : BG.CopyFromLeft; }
}

export class Mill extends Actor {
  constructor(x, y, _d, tiles) {
    super(x, y);
    while (this.position.y > 0) {
      const t = tiles.get(idiv(this.position.x, W), idiv(this.position.y, H) - 1);
      if (t !== null && t.solid) break;
      this.position.offset(0, -H);
      this.position.setHeight(this.position.h + H);
    }
    this.tile = OBJECT_ROTATINGCYLINDER; this.frame = new RangedIterator(5); this.lives = 10;
  }
  act(p) {
    if (this.lives > 0) {
      if (this.frame.isFirst()) p.cmds.addSound('REACTORSND');
      this.frame.next();
      if (this.position.hasIntersection(p.hero.position.geometry)) p.hero.health.kill();
    }
  }
  render(r) {
    let y = this.position.y;
    for (let i = 0; i < idiv(this.position.h, W); i++) { r.placeTile(this.tile + this.frame.current, this.position.x, y); y += H; }
  }
  canGetShot() { return true; }
  shot(p) {
    this.lives -= 1;
    if (this.lives > 0) p.cmds.addParticleFirework(this.position.center(), 4);
    else {
      p.cmds.addSound('HITREACTOR');
      p.msgs.push({ k: 'RemoveElectricArc' });
      p.hero.score.add(20000);
      p.cmds.addParticleFirework(this.position.center(), 20);
      p.cmds.addActor(T('Score', { s: 'Score10000' }), this.position.topLeft().offset(0, idiv(this.position.h, 2) - H));
      p.cmds.addActor(T('Score', { s: 'Score10000' }), this.position.topLeft().offset(0, idiv(this.position.h, 2)));
    }
    return Absorb;
  }
  isAlive() { return this.lives > 0; }
  backgroundTileStrategy() { return BG.CopyFromLeft; }
}

export class ElectricArc extends Actor {
  constructor(x, y) { super(x, y); this.tile = OBJECT_ELECTRIC_ARC; this.frame = new RangedIterator(4); this.alive = true; }
  act(p) {
    this.frame.next();
    p.cmds.addSound('FORCEFIELD');
    this.tile = p.hero.position.geometry.hasIntersection(this.position) ? OBJECT_ELECTRIC_ARC_HURTING : OBJECT_ELECTRIC_ARC;
  }
  render(r) { r.placeTile(this.tile + this.frame.current, this.position.x, this.position.y); }
  canReceiveMessage(m) { return m.k === 'RemoveElectricArc'; }
  receiveMessage() { this.alive = false; }
  isInForeground() { return true; }
  hurtsHero(hero) { return this.position.hasIntersection(hero.position.geometry); }
  isAlive() { return this.alive; }
  backgroundTileStrategy() { return BG.CopyFromAbove; }
}
