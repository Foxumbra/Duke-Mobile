// SPDX-License-Identifier: AGPL-3.0-or-later
// Actor registry and the ActorsList container (derived from FreeNukum actor.rs).
import { Rect } from '../rect.js';
import { BackgroundAnimation, SingleAnimation, Particle, ScoreActor, PlaceHolder } from './simple.js';
import { Item } from './items.js';
import { Key, KeyHole, Door, AccessCardDoor, AccessCardSlot, GloveSlot, ExitDoor, ExpandingFloor, ShootableWall } from './world.js';
import { Balloon, Bomb, Rocket, SodaFlying, Camera } from './misc.js';
import { Conveyor, Elevator, Fan, Fire, Mill, ElectricArc } from './terrain.js';
import { UnstableFloor, Spikes, Teleporter, Acme, NoteBook, SurveillanceScreen, HostileShot } from './hazards.js';
import { MineLying, MineJumping, Robot, FireWheelBot, FlyingBall } from './enemies1.js';
import { JumpBot } from './jumpbot.js';
import { TankBot, WallCrawler } from './enemies2.js';
import { FlyingBot, RabbitoidBot, FlameGnomeBot, Water, DrProton } from './enemies3.js';
import { Absorb } from './base.js';

const PLACEHOLDERS = new Set(['HelicopterBot',
  'StoneBackground', 'FenceBackground', 'Screen']);

const CLASSES = {
  FireWheelBot, JumpBot, MineJumping, MineLying, Robot, SingleAnimation, FlyingBall, TankBot, WallCrawler,
  Camera, Particle, Rocket, Bomb, ExitDoor, NoteBook, SurveillanceScreen, HostileShot, SodaFlying,
  UnstableFloor, ExpandingFloor, Conveyor, Fan, Teleporter, Item, Balloon, AccessCardSlot, GloveSlot,
  Key, KeyHole, Door, ShootableWall, Elevator, Acme, Fire, Mill, ElectricArc, AccessCardDoor, Spikes,
  Score: ScoreActor, BackgroundAnimation, FlyingBot, RabbitoidBot, FlameGnomeBot, Water, DrProton,
};
// ConveyorRightEnd -> Conveyor, Keyhole -> KeyHole spelling differences
const ALIAS = { ConveyorRightEnd: 'Conveyor', Keyhole: 'KeyHole' };

export function createActor(type, pt, tiles) {
  if (PLACEHOLDERS.has(type.t)) return new PlaceHolder(pt.x, pt.y);
  const cls = CLASSES[ALIAS[type.t] ?? type.t];
  if (!cls) throw new Error('Unknown actor type ' + type.t);
  return new cls(pt.x, pt.y, type, tiles);
}

export class ActorsList {
  constructor() { this.actors = []; this.interactionTarget = null; }
  get count() { return this.actors.length; }

  removeDead() {
    let i = 0;
    while (i < this.actors.length) {
      if (!this.actors[i].isAlive()) {
        this.actors.splice(i, 1);
        const t = this.interactionTarget;
        if (t === i) this.interactionTarget = null;
        else if (t !== null && t > i) this.interactionTarget = t - 1;
      } else i += 1;
    }
  }

  sendMessage(message, ctx) {
    for (const a of this.actors) if (a.canReceiveMessage(message)) a.receiveMessage({ message, hero: ctx.hero, tiles: ctx.tiles });
  }

  processShot(shotPosition, ctx) {
    for (const a of this.actors) {
      if (a.canGetShot() && shotPosition.touches(a.position) && a.shot(ctx) === Absorb) return true;
    }
    return false;
  }

  startInteraction(ctx) {
    const hero = ctx.hero;
    const i = this.actors.findIndex((a) => a.heroCanInteract(hero) && hero.position.geometry.touches(a.position));
    if (i >= 0) {
      this.endInteraction(ctx);
      this.interactionTarget = i;
      this.actors[i].heroInteractStart(ctx);
    }
  }

  endInteraction(ctx) {
    const i = this.interactionTarget;
    this.interactionTarget = null;
    if (i !== null && this.actors[i]) this.actors[i].heroInteractEnd(ctx);
  }

  /** Acts every actor in view (or always-acting ones); returns whether any hurts the hero. */
  act(ctx, visibleRect) {
    let hurting = 0;
    for (const a of this.actors) {
      if (a.actsWhileInvisible() || a.position.hasIntersection(visibleRect)) {
        a.act(ctx);
        if (a.isAlive() && a.hurtsHero(ctx.hero)) hurting += 1;
      }
    }
    this.removeDead();
    return hurting > 0;
  }

  renderBackground(r, visibleRect) {
    for (const a of this.actors) if (!a.isInForeground() && a.position.hasIntersection(visibleRect)) a.render(r);
  }
  renderForeground(r, visibleRect) {
    for (const a of this.actors) if (a.isInForeground() && a.position.hasIntersection(visibleRect)) a.render(r);
  }
}

export { Rect };
