// SPDX-License-Identifier: AGPL-3.0-or-later
// Reconstructed enemies that FreeNukum leaves as placeholders (flying bot, bunny bot, fire gnome,
// water, Dr. Proton). The behaviour here is NOT ported from FreeNukum (it has none) but written
// for DukeMobile from the sprite sheet and gameplay memory, so it approximates the original.
import {
  ANIMATION_START, TILE_WIDTH as W, TILE_HEIGHT as H, HALFTILE_WIDTH as HW, HALFTILE_HEIGHT as HH,
} from '../consts.js';
import { RangedIterator, idiv, Dir, dirFactor, dirOpposite } from '../rect.js';
import { Actor, BG, Absorb, T } from './base.js';

const A = ANIMATION_START;
const solidAt = (p, x, y) => { const t = p.tiles.get(x, y); return t ? t.solid : true; };
const tx = (a) => idiv(a.position.x, W);
const ty = (a) => idiv(a.position.y, H);
const towardsHero = (a, hero) => (hero.position.geometry.x < a.position.x ? Dir.Left : Dir.Right);

/** Flying techbot: a saucer that patrols horizontally and shoots when Duke is level with it. */
export class FlyingBot extends Actor {
  constructor(x, y) {
    super(x, y);
    this.dir = Dir.Left; this.frame = new RangedIterator(6); this.cool = 0; this.alive = true;
  }
  act(p) {
    this.frame.next();
    if (this.cool > 0) this.cool -= 1;
    const nx = idiv(this.position.x + (this.dir === Dir.Left ? -HW : W + HW - 1), W);
    if (solidAt(p, nx, ty(this))) this.dir = dirOpposite(this.dir);
    else this.position.offset(dirFactor(this.dir) * HW, 0);
    const h = p.hero.position.geometry;
    const level = Math.abs(h.y - this.position.y) < H;
    const dist = Math.abs(h.x - this.position.x);
    if (this.cool === 0 && level && dist < W * 8 && towardsHero(this, p.hero) === this.dir) {
      p.cmds.addActor(T('HostileShot', { dir: this.dir }), this.position.topLeft().offset(0, 0));
      p.cmds.addSound('ENEMYSHOT');
      this.cool = 16;
    }
  }
  render(r) { r.placeTile(A + this.frame.current, this.position.x, this.position.y); }
  canGetShot() { return true; }
  shot(p) {
    p.hero.score.add(500);
    p.cmds.addActor(T('SingleAnimation', { a: 'Explosion' }), this.position.topLeft());
    p.cmds.addSound('SMALLDEATH');
    this.alive = false;
    return Absorb;
  }
  isInForeground() { return true; }
  hurtsHero(hero) { return this.position.hasIntersection(hero.position.geometry); }
  isAlive() { return this.alive; }
  backgroundTileStrategy() { return BG.CopyFromLeft; }
}

/** Bunny bot: hops towards Duke. */
export class RabbitoidBot extends Actor {
  constructor(x, y) {
    super(x, y);
    this.vy = 0; this.alive = true; this.tick = 0; this.dir = Dir.Left;
  }
  act(p) {
    this.tick += 1;
    const onGround = solidAt(p, tx(this), ty(this) + 1) && this.position.y % H === 0;
    if (onGround) {
      this.vy = 0;
      if (this.tick % 10 === 0) {
        this.dir = towardsHero(this, p.hero);
        this.vy = -3;
      }
    } else this.vy = Math.min(this.vy + 1, 3);
    if (this.vy !== 0) {
      this.position.offset(0, this.vy * HH);
      if (this.vy > 0 && solidAt(p, tx(this), ty(this) + 1)) this.position.y = ty(this) * H;
      if (this.vy < 0 && solidAt(p, tx(this), idiv(this.position.y, H))) { this.position.y += HH; this.vy = 0; }
      const nx = idiv(this.position.x + (this.dir === Dir.Left ? -HW : W + HW - 1), W);
      if (!solidAt(p, nx, ty(this))) this.position.offset(dirFactor(this.dir) * HW, 0);
    }
  }
  render(r) { r.placeTile(A + (this.vy === 0 ? 235 : 237), this.position.x, this.position.y); }
  canGetShot() { return true; }
  shot(p) {
    p.hero.score.add(1000);
    p.cmds.addActor(T('SingleAnimation', { a: 'Explosion' }), this.position.topLeft());
    p.cmds.addSound('RABBITGONE');
    this.alive = false;
    return Absorb;
  }
  isInForeground() { return true; }
  hurtsHero(hero) { return this.position.hasIntersection(hero.position.geometry); }
  isAlive() { return this.alive; }
  backgroundTileStrategy() { return BG.CopyFromLeft; }
}

/** Fire gnome: a little flame that walks along platforms. */
export class FlameGnomeBot extends Actor {
  constructor(x, y) {
    super(x, y);
    this.dir = Dir.Left; this.frame = new RangedIterator(6); this.alive = true; this.hits = 0;
  }
  act(p) {
    this.frame.next();
    if (!solidAt(p, tx(this), ty(this) + 1)) { this.position.offset(0, HH); return; }
    if (this.frame.current % 2) return;
    const nx = idiv(this.position.x + (this.dir === Dir.Left ? -HW : W + HW - 1), W);
    if (!solidAt(p, nx, ty(this)) && solidAt(p, nx, ty(this) + 1)) this.position.offset(dirFactor(this.dir) * HW, 0);
    else this.dir = dirOpposite(this.dir);
  }
  render(r) { r.placeTile(A + 241 + 2 * this.frame.current % 12, this.position.x, this.position.y); }
  canGetShot() { return true; }
  shot(p) {
    this.hits += 1;
    p.cmds.addSound('HITHEAD');
    if (this.hits >= 2) {
      p.hero.score.add(1000);
      p.cmds.addActor(T('SingleAnimation', { a: 'Explosion' }), this.position.topLeft());
      p.cmds.addSound('SMALLDEATH');
      this.alive = false;
    }
    return Absorb;
  }
  isInForeground() { return true; }
  hurtsHero(hero) { return this.position.hasIntersection(hero.position.geometry); }
  isAlive() { return this.alive; }
  backgroundTileStrategy() { return BG.CopyFromLeft; }
}

/** Water: a solid tile drawn as a translucent blue surface. */
export class Water extends Actor {
  render(r) {
    const c = r.ctx;
    c.save(); c.globalAlpha = 0.55; c.fillStyle = '#0000a8';
    c.fillRect(this.position.x + r.ox, this.position.y + r.oy, W, H);
    c.restore();
  }
  isInForeground() { return true; }
  backgroundTileStrategy() { return BG.CopyFromLeft; }
}

/** Dr. Proton: hovers in his pod, firing at Duke. Defeating him ends the episode. */
export class DrProton extends Actor {
  constructor(x, y) {
    super(x, y, W * 2, H);
    this.dir = Dir.Left; this.life = 20; this.cool = 0; this.flash = 0; this.dead = 0;
    this.frame = new RangedIterator(2);
  }
  act(p) {
    this.frame.next();
    if (this.flash > 0) this.flash -= 1;
    if (this.life <= 0) {
      this.dead += 1;
      if (this.dead % 3 === 0) {
        p.cmds.addActor(T('SingleAnimation', { a: 'Explosion' }), this.position.topLeft().offset((this.dead % 4) * HW - HW, 0));
        p.cmds.addSound('SMALLDEATH');
      }
      if (this.dead > 24) { p.level.bossDefeated = true; p.level.playState = { kind: 'LevelFinished' }; }
      return;
    }
    const nx = idiv(this.position.x + (this.dir === Dir.Left ? -HW : W * 2 + HW - 1), W);
    if (solidAt(p, nx, ty(this))) this.dir = dirOpposite(this.dir);
    else this.position.offset(dirFactor(this.dir) * HW, 0);
    if (this.cool > 0) this.cool -= 1;
    else {
      const d = towardsHero(this, p.hero);
      p.cmds.addActor(T('HostileShot', { dir: d }), this.position.topLeft().offset(d === Dir.Left ? 0 : W, 0));
      p.cmds.addSound('ENEMYSHOT');
      this.cool = 10;
    }
  }
  render(r) {
    if (this.dead > 0 && this.dead % 2) return;
    const b = A + (this.dir === Dir.Left ? 272 : 278) + (this.flash ? 0 : 2 * this.frame.current);
    r.placeTile(b, this.position.x, this.position.y);
    r.placeTile(b + 1, this.position.x + W, this.position.y);
  }
  canGetShot() { return this.life > 0; }
  shot(p) {
    this.life -= 1; this.flash = 2;
    p.cmds.addSound('HITHEAD');
    p.hero.score.add(500);
    return Absorb;
  }
  isInForeground() { return true; }
  hurtsHero(hero) { return this.life > 0 && this.position.hasIntersection(hero.position.geometry); }
  actsWhileInvisible() { return true; }
  backgroundTileStrategy() { return BG.CopyFromLeft; }
}
