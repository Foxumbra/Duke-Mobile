// SPDX-License-Identifier: AGPL-3.0-or-later
// Derived from FreeNukum actor/{backgroundanimation,singleanimation,particle,score,placeholder}.rs
import {
  TILE_WIDTH as W, TILE_HEIGHT as H, HALFTILE_WIDTH as HW, HALFTILE_HEIGHT as HH,
  ANIMATION_BROKENWALLBG, ANIMATION_STONEWINDOWBG, ANIMATION_WINDOWBG, ANIMATION_BOMBFIRE,
  ANIMATION_EXPLOSION, ANIMATION_ROBOT, OBJECT_DUSTCLOUD, OBJECT_ENEMY_GUNFIRE_LEFT,
  OBJECT_ENEMY_GUNFIRE_RIGHT, OBJECT_HERO_GUNFIRE_LEFT, OBJECT_HERO_GUNFIRE_RIGHT, OBJECT_STEAM,
  OBJECT_SPARK_BLUE, OBJECT_SPARK_GREEN, OBJECT_SPARK_PINK, OBJECT_SPARK_WHITE,
  NUMBER_100, NUMBER_200, NUMBER_500, NUMBER_1000, NUMBER_2000, NUMBER_5000, NUMBER_10000,
  NUMBER_BONUS_1_LEFT, NUMBER_BONUS_1_RIGHT, NUMBER_BONUS_2_LEFT, NUMBER_BONUS_2_RIGHT,
  NUMBER_BONUS_3_LEFT, NUMBER_BONUS_3_RIGHT, NUMBER_BONUS_4_LEFT, NUMBER_BONUS_4_RIGHT,
  NUMBER_BONUS_5_LEFT, NUMBER_BONUS_5_RIGHT, NUMBER_BONUS_6_LEFT, NUMBER_BONUS_6_RIGHT,
  NUMBER_BONUS_7_LEFT, NUMBER_BONUS_7_RIGHT,
} from '../consts.js';
import { Rect, RangedIterator } from '../rect.js';
import { Actor, T } from './base.js';

const BGANIM = {
  TextOnScreen: [0x0004, 4], HighVoltageFlash: [0x0008, 4], RedFlashlight: [0x000c, 4],
  BlueFlashlight: [0x0010, 4], Keypanel: [0x0014, 4], RedRotationLight: [0x0018, 4],
  UpArrow: [0x001c, 4], BlueLight1: [0x0020, 4], BlueLight2: [0x0021, 4],
  BlueLight3: [0x0022, 4], BlueLight4: [0x0023, 4], GreenPoison: [0x0028, 4],
  Lava: [0x002c, 4], WindowLeft: [ANIMATION_WINDOWBG, 1], WindowRight: [ANIMATION_WINDOWBG + 1, 1],
  StoneWindow: [ANIMATION_STONEWINDOWBG, 1], BrokenWall: [ANIMATION_BROKENWALLBG, 1],
};

export class BackgroundAnimation extends Actor {
  constructor(x, y, { a }) {
    super(x, y);
    [this.tile, this.n] = BGANIM[a];
    this.frame = new RangedIterator(this.n);
  }
  act() { this.frame.next(); }
  render(r) { r.placeTile(this.tile + this.frame.current, this.position.x, this.position.y); }
  isInForeground() { return false; }
}

export class SingleAnimation extends Actor {
  /** a: BombFire|Explosion|DustCloud|Steam|RobotDisappearing|HeroGunFire|EnemyGunFire ; dir: 'L'|'R' */
  constructor(x, y, { a, dir }) {
    super(x, y);
    this.canHurt = false; this.replacedBy = null;
    let tile, n;
    switch (a) {
      case 'BombFire': [tile, n, this.canHurt] = [ANIMATION_BOMBFIRE, 6, true]; break;
      case 'Explosion': [tile, n] = [ANIMATION_EXPLOSION, 6]; break;
      case 'DustCloud': [tile, n] = [OBJECT_DUSTCLOUD, 5]; break;
      case 'Steam': [tile, n] = [OBJECT_STEAM, 5]; break;
      case 'RobotDisappearing':
        [tile, n] = [ANIMATION_ROBOT + 3, 7];
        this.replacedBy = T('SingleAnimation', { a: 'Explosion' });
        break;
      case 'HeroGunFire': [tile, n] = [dir === 'L' ? OBJECT_HERO_GUNFIRE_LEFT : OBJECT_HERO_GUNFIRE_RIGHT, 1]; break;
      case 'EnemyGunFire': [tile, n] = [dir === 'L' ? OBJECT_ENEMY_GUNFIRE_LEFT : OBJECT_ENEMY_GUNFIRE_RIGHT, 1]; break;
      default: throw new Error('bad SingleAnimation ' + a);
    }
    this.tile = tile; this.frame = new RangedIterator(n);
  }
  act(p) {
    this.frame.next();
    if (!this.isAlive() && this.replacedBy) p.cmds.addActor(this.replacedBy, this.position.topLeft());
  }
  render(r) { r.placeTile(this.tile + this.frame.current, this.position.x, this.position.y); }
  hurtsHero(hero) { return this.canHurt && this.position.hasIntersection(hero.position.geometry); }
  isAlive() { return this.frame.finishedCycles === 0; }
  actsWhileInvisible() { return true; }
}

const SPARK = { Pink: OBJECT_SPARK_PINK, Blue: OBJECT_SPARK_BLUE, White: OBJECT_SPARK_WHITE, Green: OBJECT_SPARK_GREEN };

export class Particle extends Actor {
  constructor(x, y, { c }) {
    super(x, y, HW, HH);
    this.tile = SPARK[c]; this.countdown = 20;
    this.vspeed = -0.75 + Math.random() * 1.05;
    this.hspeed = -0.5 + Math.random() * 1.0;
    this.alive = true;
  }
  act() {
    if (this.countdown > 0) {
      this.countdown -= 1;
      this.position.offset(Math.trunc(W * this.hspeed), Math.trunc(H * this.vspeed));
      this.vspeed += 0.1;
    } else this.alive = false;
  }
  render(r) { r.placeTile(this.tile, this.position.x, this.position.y); }
  isInForeground() { return true; }
  isAlive() { return this.alive; }
  actsWhileInvisible() { return true; }
}
const SCORES = {
  Score100: NUMBER_100, Score200: NUMBER_200, Score500: NUMBER_500, Score1000: NUMBER_1000,
  Score2000: NUMBER_2000, Score5000: NUMBER_5000, Score10000: NUMBER_10000,
  Bonus1Left: NUMBER_BONUS_1_LEFT, Bonus1Right: NUMBER_BONUS_1_RIGHT,
  Bonus2Left: NUMBER_BONUS_2_LEFT, Bonus2Right: NUMBER_BONUS_2_RIGHT,
  Bonus3Left: NUMBER_BONUS_3_LEFT, Bonus3Right: NUMBER_BONUS_3_RIGHT,
  Bonus4Left: NUMBER_BONUS_4_LEFT, Bonus4Right: NUMBER_BONUS_4_RIGHT,
  Bonus5Left: NUMBER_BONUS_5_LEFT, Bonus5Right: NUMBER_BONUS_5_RIGHT,
  Bonus6Left: NUMBER_BONUS_6_LEFT, Bonus6Right: NUMBER_BONUS_6_RIGHT,
  Bonus7Left: NUMBER_BONUS_7_LEFT, Bonus7Right: NUMBER_BONUS_7_RIGHT,
};

export class ScoreActor extends Actor {
  constructor(x, y, { s }) { super(x, y); this.tile = SCORES[s]; this.countdown = 40; }
  act() { this.countdown -= 1; this.position.y -= 1; }
  render(r) { r.placeTile(this.tile, this.position.x, this.position.y); }
  isInForeground() { return true; }
  isAlive() { return this.countdown > 0 && this.position.y > -this.position.h; }
  actsWhileInvisible() { return true; }
}

/** Unimplemented enemies: invisible, removed immediately, leave the left tile as background. */
export class PlaceHolder extends Actor {
  constructor(x, y) { super(x, y); }
  isAlive() { return false; }
  backgroundTileStrategy() { return { k: 'CopyFromLeft' }; }
}
