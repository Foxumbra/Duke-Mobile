// SPDX-License-Identifier: AGPL-3.0-or-later
// Derived from FreeNukum actor/{key,keyhole,door,accesscarddoor,accesscardslot,gloveslot,exitdoor,
// expandingfloor,shootablewall}.rs (c) Wolfgang Silbermayr, ported to JavaScript.
import {
  OBJECT_KEY_RED, OBJECT_KEY_GREEN, OBJECT_KEY_BLUE, OBJECT_KEY_PINK, OBJECT_KEYHOLE_BLACK,
  OBJECT_KEYHOLE_RED, OBJECT_KEYHOLE_GREEN, OBJECT_KEYHOLE_BLUE, OBJECT_KEYHOLE_PINK, OBJECT_DOOR,
  OBJECT_LASERBEAM, OBJECT_ACCESS_CARD_SLOT, OBJECT_GLOVE_SLOT, ANIMATION_EXITDOOR,
  SOLID_EXPANDINGFLOOR, BACKGROUND_LIGHT_GREY, SOLID_SHOOTABLE_WALL_BRICKS,
  TILE_WIDTH as W, TILE_HEIGHT as H,
} from '../consts.js';
import { RangedIterator } from '../rect.js';
import { Item as InvItem } from '../hero.js';
import { Actor, BG, Absorb, T } from './base.js';

const KEY_TILE = { red: OBJECT_KEY_RED, green: OBJECT_KEY_GREEN, blue: OBJECT_KEY_BLUE, pink: OBJECT_KEY_PINK };
const HOLE_TILE = { red: OBJECT_KEYHOLE_RED, green: OBJECT_KEYHOLE_GREEN, blue: OBJECT_KEYHOLE_BLUE, pink: OBJECT_KEYHOLE_PINK };
const tileOf = (a) => [Math.trunc(a.position.x / W), Math.trunc(a.position.y / H)];

export class Key extends Actor {
  constructor(x, y, { color }) { super(x, y); this.color = color; this.alive = true; }
  act(p) {
    if (p.hero.position.geometry.hasIntersection(this.position)) {
      p.hero.inventory.set(InvItem.Key(this.color));
      p.hero.score.add(1000);
      p.cmds.addActor(T('Score', { s: 'Score1000' }), this.position.topLeft());
      this.alive = false;
      p.cmds.addSound('GETKEY');
    }
  }
  render(r) { r.placeTile(KEY_TILE[this.color], this.position.x, this.position.y); }
  isAlive() { return this.alive; }
  backgroundTileStrategy() { return BG.CopyFromLeft; }
}

export class KeyHole extends Actor {
  constructor(x, y, { color }) {
    super(x, y); this.color = color; this.tile = OBJECT_KEYHOLE_BLACK;
    this.frame = new RangedIterator(8); this.opened = false;
  }
  act() { this.frame.next(); }
  render(r) {
    const tile = this.frame.current < Math.trunc(this.frame.maxValue() / 2) ? this.tile : HOLE_TILE[this.color];
    r.placeTile(tile, this.position.x, this.position.y);
  }
  heroCanInteract() { return true; }
  heroInteractStart(p) {
    const need = InvItem.Key(this.color);
    if (this.opened) return;
    if (p.hero.inventory.isSet(need)) {
      p.msgs.push({ k: 'OpenDoor', color: this.color });
      this.frame.reset(1);
      this.opened = true;
      p.hero.inventory.unset(need);
      p.cmds.addSound('OPENKEYDOOR');
    } else {
      p.info(`You don't have the ${this.color} key.`);
    }
  }
}

export class Door extends Actor {
  constructor(x, y, { color }) { super(x, y); this.color = color; this.tile = OBJECT_DOOR; this.counter = 0; this.state = 'Closed'; }
  act(p) {
    if (this.state === 'Opening') {
      if (this.counter === 0) { const t = p.tiles.get(...tileOf(this)); if (t) t.solid = false; }
      this.counter += 1;
      if (this.counter === 8) this.state = 'Open';
    }
  }
  render(r) { r.placeTile(this.tile + this.counter, this.position.x, this.position.y); }
  canReceiveMessage(m) { return m.k === 'OpenDoor' && m.color === this.color; }
  receiveMessage() { this.state = 'Opening'; }
  isAlive() { return this.state !== 'Open'; }
  backgroundTileStrategy() { return BG.CopyFromLeft; }
}

export class AccessCardDoor extends Actor {
  constructor(x, y) { super(x, y); this.tile = OBJECT_LASERBEAM; this.frame = new RangedIterator(4); this.alive = true; }
  act(p) { this.frame.next(); p.cmds.addSound('FORCEFIELD'); }
  render(r) { r.placeTile(this.tile + this.frame.current, this.position.x, this.position.y); }
  canReceiveMessage(m) { return m.k === 'OpenDoorAccessCard'; }
  receiveMessage(p) { const t = p.tiles.get(...tileOf(this)); if (t) t.solid = false; this.alive = false; }
  isAlive() { return this.alive; }
  backgroundTileStrategy() { return BG.CopyFromLeft; }
}

export class AccessCardSlot extends Actor {
  constructor(x, y) { super(x, y); this.tile = OBJECT_ACCESS_CARD_SLOT; this.frame = new RangedIterator(8); }
  heroCanInteract() { return true; }
  heroInteractStart(p) {
    if (p.hero.inventory.isSet(InvItem.AccessCard)) {
      p.msgs.push({ k: 'OpenDoorAccessCard' });
      this.frame.reset(1);
      this.tile = OBJECT_ACCESS_CARD_SLOT + 8;
      p.hero.inventory.unset(InvItem.AccessCard);
    } else p.info("You don't have the access card\n");
  }
  act() { this.frame.next(); }
  render(r) { r.placeTile(this.tile + this.frame.current, this.position.x, this.position.y); }
}

export class GloveSlot extends Actor {
  constructor(x, y) { super(x, y); this.tile = OBJECT_GLOVE_SLOT; this.frame = new RangedIterator(4); this.state = 'Idle'; this.countdown = 0; }
  heroCanInteract() { return true; }
  heroInteractStart(p) {
    if (this.state !== 'Idle') return;
    if (p.hero.inventory.isSet(InvItem.Glove)) {
      p.msgs.push({ k: 'ExpandFloor' });
      p.cmds.addSound('BRIDGEXTEND');
      this.state = 'Expanded';
    } else { this.state = 'Shooting'; this.countdown = 20; }
  }
  act(p) {
    if (this.state === 'Idle') this.frame.next();
    else if (this.state === 'Shooting') {
      this.frame.next();
      this.countdown -= 1;
      if (this.countdown % 4 === 0) {
        p.cmds.addActor(T('HostileShot', { dir: 'R' }), this.position.topLeft());
        p.cmds.addSound('ENEMYSHOT');
      } else if (this.countdown % 4 === 2) {
        p.cmds.addActor(T('HostileShot', { dir: 'L' }), this.position.topLeft());
        p.cmds.addSound('ENEMYSHOT');
      }
      if (this.countdown === 0) this.state = 'Idle';
    }
  }
  render(r) {
    const adder = this.frame.isFirst() ? 0 : 1;
    let x = this.position.x;
    r.placeTile(this.tile + adder, x, this.position.y);
    r.placeTile(this.tile + 2, x - W, this.position.y);
    r.placeTile(this.tile + 3, x + W, this.position.y);
  }
}

export class ExitDoor extends Actor {
  constructor(x, y) { super(x, y, W * 2, H * 2); this.tile = ANIMATION_EXITDOOR; this.counter = 0; this.state = 'Closed'; }
  heroCanInteract() { return true; }
  heroInteractStart(p) {
    if (this.state === 'Closed') { this.state = 'Opening'; p.cmds.addSound('DOORSND'); }
  }
  act(p) {
    if (this.state === 'Opening') {
      this.counter += 1;
      if (this.counter >= 4) { p.hero.hidden = true; this.state = 'Closing'; this.counter -= 1; }
    } else if (this.state === 'Closing') {
      if (this.counter === 0) { p.level.playState = { kind: 'LevelFinished' }; p.hero.hidden = false; }
      else this.counter -= 1;
    }
  }
  render(r) {
    const b = this.tile + this.counter * 4, x = this.position.x, y = this.position.y;
    r.placeTile(b, x, y); r.placeTile(b + 1, x + W, y);
    r.placeTile(b + 2, x, y + H); r.placeTile(b + 3, x + W, y + H);
  }
}

export class ExpandingFloor extends Actor {
  constructor(x, y) { super(x, y); this.expanding = false; this.finished = false; }
  act(p) {
    if (!this.expanding) return;
    const x = Math.trunc(this.position.right() / W), y = Math.trunc(this.position.top() / H);
    const t = p.tiles.get(x, y);
    if (t && !t.solid) { t.solid = true; this.position.setWidth(this.position.w + W); }
    else { this.expanding = false; this.finished = true; }
  }
  render(r) {
    let x = this.position.x;
    for (let i = 0; i < Math.trunc(this.position.w / W); i++) { r.placeTile(SOLID_EXPANDINGFLOOR, x, this.position.y); x += W; }
  }
  canReceiveMessage(m) { return m.k === 'ExpandFloor'; }
  receiveMessage() { if (!this.expanding && !this.finished) this.expanding = true; }
}

export class ShootableWall extends Actor {
  constructor(x, y) { super(x, y); this.alive = true; }
  canGetShot() { return true; }
  shot(p) {
    p.hero.score.add(10);
    p.cmds.addActor(T('SingleAnimation', { a: 'Explosion' }), this.position.topLeft());
    p.cmds.addSound('HITABREAKER');
    this.alive = false;
    const t = p.tiles.get(...tileOf(this)); if (t) t.solid = false;
    return Absorb;
  }
  render(r) {
    r.placeTile(BACKGROUND_LIGHT_GREY, this.position.x, this.position.y);
    r.placeTile(SOLID_SHOOTABLE_WALL_BRICKS, this.position.x, this.position.y);
  }
  isAlive() { return this.alive; }
  backgroundTileStrategy() { return BG.SetTile(Math.trunc(0x17e0 / 0x20)); }
}
