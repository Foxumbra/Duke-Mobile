// SPDX-License-Identifier: AGPL-3.0-or-later
// Derived from FreeNukum actor/{unstablefloor,spikes,teleporter,acme,notebook,surveillancescreen,
// hostileshot}.rs (c) Wolfgang Silbermayr, ported to JavaScript.
import {
  SOLID_START, OBJECT_SPIKES_UP, OBJECT_SPIKES_DOWN, OBJECT_SPIKE, ANIMATION_TELEPORTER1,
  OBJECT_FALLINGBLOCK, OBJECT_NOTEBOOK, ANIMATION_BADGUYSCREEN, OBJECT_HOSTILESHOT,
  TILE_WIDTH as W, TILE_HEIGHT as H,
} from '../consts.js';
import { RangedIterator, idiv, dirFactor, Dir } from '../rect.js';
import { Actor, BG, Absorb, T } from './base.js';

export class UnstableFloor extends Actor {
  constructor(x, y, _d, tiles) {
    super(x, y);
    let len = 0;
    for (;;) {
      const t = tiles.get(idiv(this.position.x, W) + len, idiv(this.position.y, H));
      if (!(t && !t.solid)) break;
      t.solid = true; len += 1;
    }
    this.position.resize(W * len, H);
    this.tile = SOLID_START + 77; this.touchCount = 0; this.touching = false; this.len = len;
  }
  act(p) {
    const g = p.hero.position.geometry;
    const center = g.x + idiv(g.w, 2);
    const stands = center >= this.position.left() && center <= this.position.right() && g.bottom() === this.position.top();
    if (stands) { if (!this.touching) { this.touching = true; this.touchCount += 1; } }
    else this.touching = false;
    if (!this.isAlive()) {
      const r = this.position.clone();
      for (let i = 0; i < this.len; i++) {
        const t = p.tiles.get(idiv(r.x, W), idiv(r.y, H)); if (t) t.solid = false;
        p.cmds.addActor(T('SingleAnimation', { a: 'Explosion' }), r.topLeft());
        p.cmds.addParticleFirework(r.center(), 4);
        p.cmds.addSound('BOXEXPLODE');
        r.offset(W, 0);
      }
    }
  }
  render(r) { for (let i = 0; i < this.len; i++) r.placeTile(this.tile, this.position.x + i * W, this.position.y); }
  isAlive() { return this.touchCount < 2; }
  backgroundTileStrategy() { return BG.CopyFromAbove; }
}

export class Spikes extends Actor {
  constructor(x, y, { sp }) { super(x, y); this.sp = sp; this.touching = false; }
  act(p) { this.touching = this.position.hasIntersection(p.hero.position.geometry); }
  render(r) {
    const tile = this.sp === 'SpikesUp' ? OBJECT_SPIKES_UP : this.sp === 'SpikesDown' ? OBJECT_SPIKES_DOWN
      : this.touching ? OBJECT_SPIKE + 1 : OBJECT_SPIKE;
    r.placeTile(tile, this.position.x, this.position.y);
  }
  isInForeground() { return true; }
  hurtsHero(hero) { return this.position.hasIntersection(hero.position.geometry); }
  backgroundTileStrategy() { return this.sp === 'SpikesDown' ? BG.CopyFromBelow : BG.CopyFromAbove; }
}

export class Teleporter extends Actor {
  constructor(x, y, { index }) {
    super(x - W, y - 2 * H, W * 3, H * 3);
    this.index = index; this.frame = new RangedIterator(12); this.state = 'Idle';
  }
  heroCanInteract() { return true; }
  heroInteractStart(p) {
    if (this.state === 'Idle') this.state = 'Sending';
    p.cmds.addSound('TELEPORT');
  }
  act(p) {
    if (this.state === 'Sending') {
      this.frame.next();
      if (this.frame.isFirst()) {
        p.msgs.push({ k: 'TeleportTo', index: this.index === 'First' ? 'Second' : 'First' });
        this.state = 'Idle';
      }
    } else if (this.state === 'Receiving') {
      this.frame.next();
      if (this.frame.isFirst()) this.state = 'Idle';
    }
  }
  render(r) {
    const f = this.frame.current;
    for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) {
      let extra = 0;
      if (i === 1 && j === 1) extra = [0, 8, 9][f % 3];
      else if (i === 1 && j === 2) extra = [0, 9, 10][f % 3];
      else if (i === 0 && j === 1 && (this.state === 'Sending' || this.state === 'Receiving')) extra = [0, 8, 0, 9][f % 4];
      const x = this.position.x + j * W, y = this.position.y + i * H;
      r.placeTile(ANIMATION_TELEPORTER1 + i * 3 + j, x, y);
      if (extra !== 0) r.placeTile(ANIMATION_TELEPORTER1 + i * 3 + j + extra, x, y);
    }
  }
  canReceiveMessage(m) { return m.k === 'TeleportTo' && m.index === this.index; }
  receiveMessage(p) {
    this.state = 'Receiving';
    p.hero.position.moveTo(this.position.x + W, this.position.y + H);
  }
  isInForeground() { return true; }
}

export class Acme extends Actor {
  constructor(x, y) { super(x, y, W * 2, H); this.tile = OBJECT_FALLINGBLOCK; this.counter = 0; this.alive = true; }
  act(p) {
    const g = p.hero.position.geometry, c = this.counter;
    if (c === 0) {
      const xl = this.position.left(), xr = this.position.right(), y = this.position.y;
      if (y < g.y && xl < g.right() && xr > g.left()) {
        let solidBetween = false;
        for (let i = idiv(y, H) + 1; i < idiv(g.y, H); i++) {
          const x = idiv(xl, W);
          const a = p.tiles.get(x, i); if (a && a.solid) { solidBetween = true; break; }
          const b = p.tiles.get(x + 1, i); if (b && b.solid) { solidBetween = true; break; }
        }
        if (!solidBetween) this.counter += 1;
      }
    } else if (c <= 10 && c % 2 === 0) {
      this.position.y -= 1; this.counter += 1;
      if (c === 10) p.cmds.addSound('DANDERSIGN');
    } else if (c <= 10 && c % 2 === 1) {
      this.position.y += 1; this.counter += 1;
    } else {
      const t = p.tiles.get(idiv(this.position.x, W), idiv(this.position.y, H) + 1);
      if (t && t.solid) {
        p.cmds.addActor(T('SingleAnimation', { a: 'Steam' }), this.position.topLeft());
        p.cmds.addParticleFirework(this.position.topLeft(), 4);
        this.alive = false;
      } else this.position.offset(0, H);
    }
  }
  render(r) { r.placeTile(this.tile, this.position.x, this.position.y); r.placeTile(this.tile + 1, this.position.x + W, this.position.y); }
  canGetShot() { return true; }
  shot(p) {
    if (this.counter > 0) {
      p.hero.score.add(500);
      p.cmds.addActor(T('Score', { s: 'Score500' }), this.position.topLeft());
      p.cmds.addParticleFirework(this.position.topLeft(), 4);
      this.alive = false;
    }
    return Absorb;
  }
  isInForeground() { return true; }
  hurtsHero(hero) { return this.counter > 10 && this.position.hasIntersection(hero.position.geometry); }
  isAlive() { return this.alive; }
  backgroundTileStrategy() { return BG.CopyFromLeft; }
}

export class NoteBook extends Actor {
  constructor(x, y) { super(x, y); }
  heroCanInteract() { return true; }
  heroInteractStart(p) { p.cmds.addSound('READNOTE'); p.info({ note: 'notebook' }); }
  render(r) { r.placeTile(OBJECT_NOTEBOOK, this.position.x, this.position.y); }
  backgroundTileStrategy() { return BG.CopyFromLeft; }
}

export class SurveillanceScreen extends Actor {
  constructor(x, y) { super(x, y, W * 2, H); }
  heroCanInteract() { return true; }
  heroInteractStart(p) { p.cmds.addSound('MONITOR'); p.info({ note: 'screen' }); }
  render(r) {
    r.placeTile(ANIMATION_BADGUYSCREEN, this.position.x, this.position.y);
    r.placeTile(ANIMATION_BADGUYSCREEN + 1, this.position.x + W, this.position.y);
  }
  backgroundTileStrategy() { return BG.CopyFromLeft; }
}

export class HostileShot extends Actor {
  constructor(x, y, { dir }) {
    super(x, y);
    this.dir = dir; this.tile = dir === Dir.Left ? OBJECT_HOSTILESHOT : OBJECT_HOSTILESHOT + 2;
    this.frame = new RangedIterator(2); this.alive = true;
  }
  act(p) {
    this.position.offset(W * dirFactor(this.dir), 0);
    const t = p.tiles.get(idiv(this.position.x, W), idiv(this.position.y, H));
    this.alive = !!(t && !t.solid);
    this.frame.next();
  }
  render(r) { r.placeTile(this.tile + this.frame.current, this.position.x, this.position.y); }
  isInForeground() { return true; }
  hurtsHero(hero) { return this.position.hasIntersection(hero.position.geometry); }
  isAlive() { return this.alive; }
  actsWhileInvisible() { return true; }
}
