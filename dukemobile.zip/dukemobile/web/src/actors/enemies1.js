// SPDX-License-Identifier: AGPL-3.0-or-later
// Derived from FreeNukum actor/{minelying,minejumping,robot,firewheelbot,flyingball}.rs
// (c) Wolfgang Silbermayr, ported to JavaScript.
import {
  ANIMATION_MINE, ANIMATION_ROBOT, ANIMATION_FIREWHEEL_ON, ANIMATION_FIREWHEEL_OFF, ANIMATION_BALL,
  TILE_WIDTH as W, TILE_HEIGHT as H, HALFTILE_WIDTH as HW, HALFTILE_HEIGHT as HH,
} from '../consts.js';
import { RangedIterator, idiv, Dir, dirFactor, dirOpposite } from '../rect.js';
import { Actor, BG, Absorb, T } from './base.js';

const tileXY = (a) => [idiv(a.position.x, W), idiv(a.position.y, H)];

export class MineLying extends Actor {
  constructor(x, y) { super(x, y); this.tile = ANIMATION_MINE; this.alive = true; }
  act(p) {
    const [x, y] = tileXY(this);
    const below = p.tiles.get(x, y + 1);
    if (below && !below.solid) this.position.offset(0, HH);
    if (p.hero.position.geometry.hasIntersection(this.position)) {
      this.alive = false;
      p.cmds.addActor(T('SingleAnimation', { a: 'BombFire' }), this.position.topLeft());
    }
  }
  render(r) { r.placeTile(this.tile, this.position.x, this.position.y); }
  isInForeground() { return true; }
  isAlive() { return this.alive; }
  backgroundTileStrategy() { return BG.CopyFromAbove; }
}

const MINE_REL = [0, 1, 1.75, 2.25, 2.5, 2.56, 2.64, 2.56, 2.5, 2.25, 1.75, 1];

export class MineJumping extends Actor {
  constructor(x, y) { super(x, y); this.tile = ANIMATION_MINE; this.frame = new RangedIterator(12); this.baseY = y; }
  act(p) {
    this.position.y = this.baseY - Math.trunc(H * MINE_REL[this.frame.current]);
    if (this.frame.isFirst()) p.cmds.addSound('MINEBOUNCE');
    this.frame.next();
  }
  render(r) { r.placeTile(this.tile, this.position.x, this.position.y); }
  canGetShot() { return true; }
  shot() { return Absorb; }
  isInForeground() { return true; }
  hurtsHero(hero) { return this.position.hasIntersection(hero.position.geometry); }
  backgroundTileStrategy() { return BG.CopyFromLeft; }
}

export class Robot extends Actor {
  constructor(x, y) {
    super(x, y);
    this.dir = Dir.Left; this.tile = ANIMATION_ROBOT; this.frame = new RangedIterator(3); this.alive = true;
  }
  act(p) {
    this.frame.next();
    const [x, y] = tileXY(this);
    const below = p.tiles.get(x, y + 1);
    if (below && !below.solid) { this.position.offset(0, HH); return; }
    if (!this.frame.isFirst()) return;
    let d = this.dir === Dir.Left ? -1 : 2;
    const nx = idiv(this.position.x + d * HW, W);
    const free = p.tiles.get(nx, y), floor = p.tiles.get(nx, idiv(this.position.y + H, H));
    if (free && !free.solid && floor && floor.solid) {
      if (d === 2) d = 1;
      this.position.offset(d * HW, 0);
    } else {
      this.dir = dirOpposite(this.dir);
      if (d === 2) d = 1;
      d *= -1;
      this.position.offset(d * HW, 0);
    }
  }
  render(r) { r.placeTile(this.tile, this.position.x, this.position.y); }
  canGetShot() { return true; }
  shot(p) {
    p.hero.score.add(100);
    p.cmds.addActor(T('SingleAnimation', { a: 'RobotDisappearing' }), this.position.topLeft());
    p.cmds.addSound('SMALLDEATH');
    this.alive = false;
    return Absorb;
  }
  isInForeground() { return true; }
  hurtsHero(hero) { return this.position.hasIntersection(hero.position.geometry); }
  isAlive() { return this.alive; }
  backgroundTileStrategy() { return BG.CopyFromLeft; }
}

export class FireWheelBot extends Actor {
  constructor(x, y) {
    super(x, y);
    this.dir = Dir.Left; this.tile = ANIMATION_FIREWHEEL_OFF; this.counter = 0;
    this.frame = new RangedIterator(4); this.wasShot = 0; this.fireIsOn = false;
  }
  act(p) {
    if (this.wasShot === 2) {
      p.cmds.addActor(T('SingleAnimation', { a: 'Explosion' }), this.position.topLeft().offset(HW, 0));
      p.cmds.addParticleFirework(this.position.topLeft(), 8);
      p.hero.score.add(2500);
      return;
    }
    this.counter += 1;
    if (this.counter % 2 === 1) this.frame.next();
    if (this.counter === 50) {
      this.counter = 0;
      this.fireIsOn = !this.fireIsOn;
      this.tile = this.fireIsOn ? ANIMATION_FIREWHEEL_ON : ANIMATION_FIREWHEEL_OFF;
    }
    if (!p.tiles.pushRectStandingOnGround(this.position, dirFactor(this.dir) * idiv(HW, 2), HH)) {
      this.dir = dirOpposite(this.dir);
    }
    if (this.wasShot === 1 && this.frame.isFirst()) {
      p.cmds.addActor(T('SingleAnimation', { a: 'Steam' }), this.position.topLeft().offset(HW, -H));
    }
  }
  render(r) {
    let x = this.position.x + idiv(this.position.w, 2) - W, y = this.position.y - H;
    const f = this.frame.current * 4;
    r.placeTile(this.tile + f, x, y); r.placeTile(this.tile + f + 1, x + W, y);
    r.placeTile(this.tile + f + 2, x, y + H); r.placeTile(this.tile + f + 3, x + W, y + H);
  }
  canGetShot() { return true; }
  shot() { if (!this.fireIsOn && this.wasShot < 2) this.wasShot += 1; return Absorb; }
  isInForeground() { return true; }
  hurtsHero(hero) { return this.wasShot < 2 && this.position.hasIntersection(hero.position.geometry); }
  isAlive() { return this.wasShot < 2; }
  backgroundTileStrategy() { return BG.CopyFromLeft; }
}

const POS_OFFSETS = [
  ...Array(9).fill([128, 0]),
  [128, 8], [120, 16], [112, 24], [96, 32], [80, 32], [64, 24], [56, 16], [48, 8],
  [48, 0], [56, -8], [64, -16], [80, -24], [96, -24], [112, -16], [120, -8], [128, 0],
  [128, 8], [136, 16], [144, 24], [160, 32], [176, 32], [192, 24], [200, 16], [208, 8],
  [208, 0], [200, -8], [192, -16], [176, -24], [160, -24], [144, -16], [136, -8],
];
if (POS_OFFSETS.length !== 40) throw new Error('FlyingBall offsets must have 40 entries');

export class FlyingBall extends Actor {
  constructor(x, y, { i }) {
    super(x, y);
    this.base = { x, y };
    this.tile = ANIMATION_BALL;
    this.frame = new RangedIterator(8 * 3);
    this.posIter = new RangedIterator(POS_OFFSETS.length);
    for (let k = 0; k < i; k++) { this.posIter.next(); this.frame.next(); }
    const o = POS_OFFSETS[this.posIter.current];
    this.position.x = x + o[0]; this.position.y = y + o[1];
    this.alive = true;
  }
  act() {
    const o = POS_OFFSETS[this.posIter.current];
    this.position.x = this.base.x + o[0]; this.position.y = this.base.y + o[1];
    this.frame.next(); this.posIter.next();
  }
  render(r) { r.placeTile(this.tile + idiv(this.frame.current, 3), this.position.x, this.position.y); }
  canGetShot() { return true; }
  shot(p) {
    p.hero.score.add(1000);
    p.cmds.addParticleFirework(this.position.topLeft(), 4);
    p.cmds.addSound('SMALLDEATH');
    this.alive = false;
    return Absorb;
  }
  isInForeground() { return true; }
  hurtsHero(hero) { return this.position.hasIntersection(hero.position.geometry); }
  actsWhileInvisible() { return true; }
  isAlive() { return this.alive; }
  backgroundTileStrategy() { return BG.CopyFromLeft; }
}
