// SPDX-License-Identifier: AGPL-3.0-or-later
// Derived from FreeNukum actor/{balloon,bomb,rocket,sodaflying,camera}.rs (c) Wolfgang Silbermayr.
import {
  OBJECT_BALLOON, ANIMATION_BOMB, OBJECT_ROCKET, ANIMATION_SODAFLY, ANIMATION_CAMERA_CENTER,
  ANIMATION_CAMERA_LEFT, ANIMATION_CAMERA_RIGHT, TILE_WIDTH as W, TILE_HEIGHT as H,
  HALFTILE_HEIGHT as HH,
} from '../consts.js';
import { RangedIterator, idiv } from '../rect.js';
import { Actor, BG, Absorb, T } from './base.js';

const tx = (a) => idiv(a.position.x, W), ty = (a) => idiv(a.position.y, H);

export class Balloon extends Actor {
  constructor(x, y) { super(x, y, W, H * 2); this.destroyed = false; this.frame = new RangedIterator(9); this.alive = true; }
  act(p) {
    this.frame.next();
    this.alive = !this.destroyed;
    if (this.position.hasIntersection(p.hero.position.geometry)) {
      this.alive = false;
      p.hero.score.add(10000);
      p.cmds.addActor(T('Score', { s: 'Score10000' }), this.position.topLeft());
      p.cmds.addSound('GETBALLON');
    } else {
      this.position.y -= 1;
      const t = p.tiles.get(tx(this), ty(this));
      if (t && t.solid) {
        this.destroyed = true;
        p.cmds.addActor(T('SingleAnimation', { a: 'Steam' }), this.position.topLeft());
      }
    }
  }
  render(r) {
    const x = this.position.x, y = this.position.y;
    r.placeTile(this.destroyed ? OBJECT_BALLOON + 4 : OBJECT_BALLOON, x, y);
    r.placeTile(OBJECT_BALLOON + 1 + idiv(this.frame.current, 3), x, y + H);
  }
  canGetShot() { return true; }
  shot(p) {
    this.destroyed = true;
    p.cmds.addActor(T('SingleAnimation', { a: 'Steam' }), this.position.topLeft());
    return Absorb;
  }
  isInForeground() { return true; }
  isAlive() { return this.alive; }
}

export class Bomb extends Actor {
  constructor(x, y) {
    super(x, y);
    this.tile = ANIMATION_BOMB; this.frame = new RangedIterator(2); this.counter = 0;
    this.explodeLeft = true; this.explodeRight = true; this.threshold = 12; this.numFlames = 4;
  }
  act(p) {
    this.frame.next();
    this.counter += 1;
    if (this.counter < this.threshold) return;
    if (this.counter < this.threshold + this.numFlames) {
      const d = this.counter - this.threshold;
      const bx = tx(this), by = ty(this);
      const side = (dir) => {
        const here = p.tiles.get(bx + dir * d, by), below = p.tiles.get(bx + dir * d, by + 1);
        return here && !here.solid && below && below.solid;
      };
      if (this.explodeLeft) {
        if (side(-1)) {
          p.cmds.addSound('BOMBEXPLODE');
          p.cmds.addActor(T('SingleAnimation', { a: 'BombFire' }), this.position.topLeft().offset(-d * W, 0));
        } else this.explodeLeft = false;
      }
      if (this.explodeRight) {
        if (side(1)) p.cmds.addActor(T('SingleAnimation', { a: 'BombFire' }), this.position.topLeft().offset(d * W, 0));
        else this.explodeRight = false;
      }
    }
  }
  render(r) {
    if (this.counter < this.threshold) r.placeTile(this.tile + this.frame.current, this.position.x, this.position.y);
  }
  isInForeground() { return true; }
  isAlive() { return this.counter < this.threshold + this.numFlames; }
  actsWhileInvisible() { return true; }
}

export class Rocket extends Actor {
  constructor(x, y) { super(x, y); this.state = 'Idle'; }
  act(p) {
    if (this.state !== 'Flying') return;
    this.position.offset(0, -HH);
    if (p.tiles.collides(this.position)) {
      const x = tx(this), y = ty(this);
      if (p.tiles.isInRange(x, y + 1)) p.tiles.get(x, y + 1).solid = false;
      if (p.tiles.isInRange(x, y) && p.tiles.isInRange(x, y - 1)) p.tiles.copyEffectiveNumber(x, y - 1, x, y);
    }
  }
  render(r) {
    let x = this.position.x, y = this.position.y - H * 3;
    r.placeTile(OBJECT_ROCKET, x, y);
    for (let i = 0; i < 2; i++) { y += H; r.placeTile(OBJECT_ROCKET + 1, x, y); }
    y += H; r.placeTile(OBJECT_ROCKET + 2, x, y);
    x -= W; r.placeTile(OBJECT_ROCKET + 3, x, y);
    x += 2 * W; r.placeTile(OBJECT_ROCKET + 4, x, y);
    if (this.state === 'Flying') { x -= W; y += H; r.placeTile(OBJECT_ROCKET + 6, x, y); }
  }
  canGetShot() { return true; }
  shot(p) {
    if (this.state === 'Idle') {
      this.state = 'Flying';
      p.cmds.addSound('ROCKET');
      const x = tx(this), y = idiv(this.position.y + this.position.h, H);
      const below = p.tiles.get(x, y + 1);
      const source = below ? below.effective : 0;
      const t = p.tiles.get(x, y);
      if (t) { t.solid = false; t.effective = source; }
    }
    return Absorb;
  }
  backgroundTileStrategy() { return BG.CopyFromAbove; }
  actsWhileInvisible() { return this.state !== 'Idle'; }
}

export class SodaFlying extends Actor {
  constructor(x, y) { super(x, y); this.alive = true; }
  act(p) {
    this.position.offset(0, -HH);
    if (this.position.top() % H === 0) p.cmds.addSound('COKECANHIT');
    const t = p.tiles.get(tx(this), ty(this));
    if (t && t.solid) {
      p.cmds.addActor(T('SingleAnimation', { a: 'Explosion' }), this.position.topLeft());
      this.alive = false;
    } else if (this.position.hasIntersection(p.hero.position.geometry)) {
      p.hero.score.add(1000);
      p.cmds.addActor(T('Score', { s: 'Score1000' }), this.position.topLeft());
      p.cmds.addSound('GETBONUSOBJ');
      this.alive = false;
    }
  }
  render(r) {
    // position.y is non-negative in practice; keep integer division semantics of usize
    r.placeTile(ANIMATION_SODAFLY + (idiv(Math.max(0, this.position.y), HH) % 4), this.position.x, this.position.y);
  }
  isInForeground() { return true; }
  isAlive() { return this.alive; }
}

export class Camera extends Actor {
  constructor(x, y) { super(x, y); this.tile = ANIMATION_CAMERA_CENTER; this.alive = true; }
  act(p) {
    const x = p.hero.position.geometry.x;
    this.tile = x - 1 > this.position.x ? ANIMATION_CAMERA_RIGHT
      : x + 1 < this.position.x ? ANIMATION_CAMERA_LEFT : ANIMATION_CAMERA_CENTER;
  }
  render(r) { r.placeTile(this.tile, this.position.x, this.position.y); }
  canGetShot() { return true; }
  shot(p) {
    this.alive = false;
    p.hero.score.add(100);
    p.cmds.addActor(T('Score', { s: 'Score100' }), this.position.topLeft());
    p.cmds.addActor(T('SingleAnimation', { a: 'Explosion' }), this.position.topLeft());
    p.cmds.addSound('SMALLDEATH');
    return Absorb;
  }
  isAlive() { return this.alive; }
  backgroundTileStrategy() { return BG.CopyFromBelow; }
}
