// SPDX-License-Identifier: AGPL-3.0-or-later
// Derived from FreeNukum actor.rs (c) Wolfgang Silbermayr, ported to JavaScript.
import { Rect } from '../rect.js';
import { TILE_WIDTH as W, TILE_HEIGHT as H } from '../consts.js';

export const Absorb = 'absorb', Ignore = 'ignore';

/** Background tile strategies used when an actor replaces the level tile it sits on. */
export const BG = Object.freeze({
  KeepEmpty: { k: 'KeepEmpty' },
  CopyFromAbove: { k: 'CopyFromAbove' },
  CopyFromLeft: { k: 'CopyFromLeft' },
  CopyFromRight: { k: 'CopyFromRight' },
  CopyFromBelow: { k: 'CopyFromBelow' },
  SetTile: (n) => ({ k: 'SetTile', n }),
});

/**
 * Base class. Parameter objects passed to act/shot/etc. are:
 *   p = { tiles, hero, cmds, msgs, level }
 * `cmds` offers addActor(type, point), addSound(name), addParticleFirework(point, n).
 * `level.playState` is mutable ({kind:'Playing'|'LevelFinished'|...}).
 */
export class Actor {
  constructor(x, y, w = W, h = H) { this.position = new Rect(x, y, w, h); }
  heroCanInteract(_hero) { return false; }
  heroInteractStart(_p) {}
  heroInteractEnd(_p) {}
  act(_p) {}
  render(_r) {}
  canGetShot() { return false; }
  shot(_p) { return Ignore; }
  isInForeground() { return false; }
  hurtsHero(_hero) { return false; }
  isAlive() { return true; }
  actsWhileInvisible() { return false; }
  canReceiveMessage(_m) { return false; }
  receiveMessage(_p) {}
  backgroundTileStrategy() { return BG.KeepEmpty; }
}

/** Plain-data actor type constructors. {t: 'Name', ...details} */
export const T = (t, extra = {}) => ({ t, ...extra });
