// SPDX-License-Identifier: AGPL-3.0-or-later
// Derived from FreeNukum actor/{tankbot,wallcrawler}.rs (c) Wolfgang Silbermayr, ported to JavaScript.
import {
  ANIMATION_CARBOT, ANIMATION_WALLCRAWLERBOT_LEFT, ANIMATION_WALLCRAWLERBOT_RIGHT,
  TILE_WIDTH as W, TILE_HEIGHT as H, HALFTILE_WIDTH as HW, HALFTILE_HEIGHT as HH,
} from '../consts.js';
import { RangedIterator, idiv, Dir, dirFactor, dirOpposite } from '../rect.js';
import { Actor, BG, Absorb, T } from './base.js';

export class TankBot extends Actor {
  constructor(x, y) {
    super(x, y, W * 2, H);
    this.orientation = Dir.Left; this.tile = ANIMATION_CARBOT; this.frame = new RangedIterator(4); this.state = 'Healthy';
  }
  act(p) {
    this.frame.next();
    const bx = idiv(this.position.x, W), by = idiv(this.position.y, H);
    const below = p.tiles.get(bx, by + 1);
    const solidBelow = below ? below.solid : true;
    if (!solidBelow) this.position.offset(0, HH);
    else {
      let d = this.orientation === Dir.Left ? -1 : 4;
      const nx = idiv(this.position.x + d * HW, W);
      const a = p.tiles.get(nx, by), b = p.tiles.get(nx, idiv(this.position.y + H, H));
      const nextSolid = a ? a.solid : true, nextBelowSolid = b ? b.solid : true;
      if (!nextSolid && nextBelowSolid) {
        if (d > 0) d = 1;
        this.position.offset(Math.trunc(d * HW * 0.7), 0);
      } else {
        this.orientation = dirOpposite(this.orientation);
        if (d > 0) d = 1;
        d *= -1;
        this.position.offset(d * HW, 0);
        this.tile = this.tile + 4 * d;
        p.cmds.addActor(T('HostileShot', { dir: this.orientation }), this.position.topLeft().offset(0, -6));
        p.cmds.addSound('ENEMYSHOT');
      }
    }
    if (this.state === 'Hurt' && this.frame.isFirst()) {
      p.cmds.addActor(T('SingleAnimation', { a: 'Steam' }), this.position.topLeft().offset(HW, -H));
    }
  }
  render(r) {
    const t = this.tile + idiv(this.frame.current, 2) * 2;
    r.placeTile(t, this.position.x, this.position.y);
    r.placeTile(t + 1, this.position.x + W, this.position.y);
  }
  canGetShot() { return true; }
  shot(p) {
    if (this.state === 'Healthy') this.state = 'Hurt';
    else if (this.state === 'Hurt') {
      p.cmds.addActor(T('SingleAnimation', { a: 'Explosion' }), this.position.topLeft().offset(HW, 0));
      p.cmds.addParticleFirework(this.position.topLeft(), 4);
      p.hero.score.add(2500);
      p.cmds.addSound('SMALLDEATH');
      this.state = 'Dead';
    }
    return Absorb;
  }
  isInForeground() { return true; }
  hurtsHero(hero) { return this.position.hasIntersection(hero.position.geometry); }
  isAlive() { return this.state !== 'Dead'; }
}

export class WallCrawler extends Actor {
  constructor(x, y, { dir }) {
    super(x, y);
    this.vdir = 'Up'; this.orientation = dir;
    this.tile = dir === Dir.Left ? ANIMATION_WALLCRAWLERBOT_LEFT : ANIMATION_WALLCRAWLERBOT_RIGHT;
    this.frame = new RangedIterator(4); this.alive = true;
  }
  act(p) {
    const o = dirFactor(this.orientation), tx = idiv(this.position.x, W);
    const solid = (x, y) => { const t = p.tiles.get(x, y); return t ? t.solid : true; };
    if (this.vdir === 'Up') {
      this.frame.next();
      const y = idiv(this.position.top() - 1, H);
      if (solid(tx, y) || !solid(tx + o, y)) { this.position.y += 1; this.vdir = 'Down'; }
      else this.position.y -= 1;
    } else {
      this.frame.rewind();
      const y = idiv(this.position.bottom() + 1, H);
      if (solid(tx, y) || !solid(tx + o, y)) { this.position.y -= 1; this.vdir = 'Up'; }
      else this.position.y += 1;
    }
  }
  render(r) { r.placeTile(this.tile + this.frame.current, this.position.x, this.position.y); }
  canGetShot() { return true; }
  shot(p) {
    this.alive = false;
    p.hero.score.add(100);
    p.cmds.addActor(T('SingleAnimation', { a: 'Steam' }), this.position.topLeft());
    p.cmds.addActor(T('SingleAnimation', { a: 'Explosion' }), this.position.topLeft());
    p.cmds.addSound('SMALLDEATH');
    return Absorb;
  }
  isInForeground() { return true; }
  hurtsHero(hero) { return this.position.hasIntersection(hero.position.geometry); }
  isAlive() { return this.alive; }
  backgroundTileStrategy() { return this.orientation === Dir.Left ? BG.CopyFromRight : BG.CopyFromLeft; }
}
