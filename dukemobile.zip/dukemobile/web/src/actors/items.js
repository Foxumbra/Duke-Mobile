// SPDX-License-Identifier: AGPL-3.0-or-later
// Derived from FreeNukum actor/item.rs (c) Wolfgang Silbermayr, ported to JavaScript.
import {
  ANIMATION_SODA, OBJECT_ACCESS_CARD, OBJECT_BOOT, OBJECT_BOX_BLUE, OBJECT_BOX_GREY, OBJECT_BOX_RED,
  OBJECT_CHICKEN_DOUBLE, OBJECT_CHICKEN_SINGLE, OBJECT_CLAMP, OBJECT_DISK, OBJECT_FLAG,
  OBJECT_FOOTBALL, OBJECT_GLOVE, OBJECT_GUN, OBJECT_JOYSTICK, OBJECT_LETTER_D, OBJECT_LETTER_E,
  OBJECT_LETTER_K, OBJECT_LETTER_U, OBJECT_NUCLEARMOLECULE, OBJECT_RADIO,
  TILE_HEIGHT as H, HALFTILE_HEIGHT as HH, TILE_WIDTH as W,
} from '../consts.js';
import { RangedIterator } from '../rect.js';
import { Item as InvItem } from '../hero.js';
import { Actor, BG, Absorb, Ignore, T } from './base.js';

// item type string -> [tile, frames]
const TILES = {
  AccessCard: [OBJECT_ACCESS_CARD, 1], Boots: [OBJECT_BOOT, 1],
  Balloon: null, // never instantiated as item
  ChickenDouble: [OBJECT_CHICKEN_DOUBLE, 1], ChickenSingle: [OBJECT_CHICKEN_SINGLE, 1],
  Clamps: [OBJECT_CLAMP, 1], Disk: [OBJECT_DISK, 1], Flag: [OBJECT_FLAG, 3],
  Football: [OBJECT_FOOTBALL, 1], FullLife: [OBJECT_NUCLEARMOLECULE, 8], Glove: [OBJECT_GLOVE, 1],
  Gun: [OBJECT_GUN, 1], Joystick: [OBJECT_JOYSTICK, 1], LetterD: [OBJECT_LETTER_D, 1],
  LetterE: [OBJECT_LETTER_E, 1], LetterK: [OBJECT_LETTER_K, 1], LetterU: [OBJECT_LETTER_U, 1],
  Radio: [OBJECT_RADIO, 3], Soda: [ANIMATION_SODA, 4],
};
const boxTile = (it) =>
  it.startsWith('BoxBlue') ? OBJECT_BOX_BLUE : it.startsWith('BoxRed') ? OBJECT_BOX_RED : OBJECT_BOX_GREY;

// pickup effects: [score, scoreActor, sound, extra(hero)]
const PICKUP = {
  FullLife: [1000, 'Score1000', 'GETPOWERUP', (h) => h.health.fillMax()],
  Gun: [1000, 'Score1000', 'SPECIALITEM', (h) => h.firepower.increase(1)],
  AccessCard: [1000, 'Score1000', 'SPECIALITEM', (h) => h.inventory.set(InvItem.AccessCard)],
  Glove: [1000, 'Score1000', 'SPECIALITEM', (h) => h.inventory.set(InvItem.Glove)],
  Boots: [1000, 'Score1000', 'SPECIALITEM', (h) => h.inventory.set(InvItem.Boot)],
  Clamps: [1000, 'Score1000', 'SPECIALITEM', (h) => h.inventory.set(InvItem.Clamp)],
  Football: [100, 'Score100', 'GETBONUSOBJ'],
  Disk: [5000, 'Score5000', 'GETBONUSOBJ'],
  Joystick: [2000, 'Score2000', 'GETBONUSOBJ'],
  Soda: [200, 'Score200', 'GETFOODITEM', (h) => h.health.increase(1)],
  ChickenSingle: [100, 'Score100', 'GETFOODITEM', (h) => h.health.increase(1)],
  ChickenDouble: [200, 'Score200', 'GETFOODITEM', (h) => h.health.increase(2)],
};

// shootable boxes: box type -> spawned thing
const BOX_CONTENT = {
  'BoxBlue.Football': T('Item', { it: 'Football' }), 'BoxBlue.Joystick': T('Item', { it: 'Joystick' }),
  'BoxBlue.Disk': T('Item', { it: 'Disk' }), 'BoxBlue.Balloon': 'balloon',
  'BoxBlue.Flag': T('Item', { it: 'Flag' }), 'BoxBlue.Radio': T('Item', { it: 'Radio' }),
  'BoxRed.Soda': T('Item', { it: 'Soda' }), 'BoxRed.Chicken': T('Item', { it: 'ChickenSingle' }),
  'BoxGrey.Nothing': null, 'BoxGrey.Boots': T('Item', { it: 'Boots' }),
  'BoxGrey.Clamps': T('Item', { it: 'Clamps' }), 'BoxGrey.Gun': T('Item', { it: 'Gun' }),
  'BoxGrey.Bomb': T('Bomb'), 'BoxGrey.Glove': T('Item', { it: 'Glove' }),
  'BoxGrey.FullLife': T('Item', { it: 'FullLife' }), 'BoxGrey.AccessCard': T('Item', { it: 'AccessCard' }),
  'BoxGrey.LetterD': T('Item', { it: 'LetterD' }), 'BoxGrey.LetterU': T('Item', { it: 'LetterU' }),
  'BoxGrey.LetterK': T('Item', { it: 'LetterK' }), 'BoxGrey.LetterE': T('Item', { it: 'LetterE' }),
};

export class Item extends Actor {
  constructor(x, y, { it }) {
    super(x, y);
    this.it = it; this.alive = true;
    if (it.startsWith('Box')) { this.tile = boxTile(it); this.frame = new RangedIterator(1); }
    else { const [t, n] = TILES[it]; this.tile = t; this.frame = new RangedIterator(n); }
  }
  touchedByHero(hero, cmds) {
    const it = this.it, at = this.position.topLeft();
    const letter = { LetterD: 'D', LetterU: 'U', LetterK: 'K', LetterE: 'E' }[it];
    if (letter) {
      this.alive = false;
      hero.fetchedLetterState.picked(letter);
      hero.score.add(500);
      if (letter === 'E' && hero.fetchedLetterState.succeeded()) {
        cmds.addActor(T('Score', { s: 'Score10000' }), at);
        hero.score.add(10000);
        cmds.addSound('GETDUKESND');
      } else if (letter === 'E') {
        cmds.addActor(T('Score', { s: 'Score500' }), at);
        hero.score.add(500);
        cmds.addSound('GETBONUSOBJ');
      } else {
        cmds.addActor(T('Score', { s: 'Score500' }), at);
        cmds.addSound('GETBONUSOBJ');
      }
      return;
    }
    if (it === 'Radio' || it === 'Flag') {
      this.alive = false;
      const [s, name] = [[100, 'Score100'], [2000, 'Score2000'], [5000, 'Score5000']][this.frame.current];
      hero.score.add(s);
      cmds.addActor(T('Score', { s: name }), at);
      cmds.addSound('GETBONUSOBJ');
      return;
    }
    const e = PICKUP[it];
    if (!e) return;
    const [score, scoreActor, sound, extra] = e;
    if (extra) extra(hero);
    this.alive = false;
    hero.score.add(score);
    cmds.addActor(T('Score', { s: scoreActor }), at);
    cmds.addSound(sound);
  }
  act(p) {
    this.frame.next();
    const t = p.tiles.get(Math.trunc(this.position.x / W), Math.trunc(this.position.y / H) + 1);
    if (t === null || !t.solid) this.position.offset(0, HH); // fall down
    if (this.position.hasIntersection(p.hero.position.geometry)) this.touchedByHero(p.hero, p.cmds);
  }
  render(r) { r.placeTile(this.tile + this.frame.current, this.position.x, this.position.y); }
  canGetShot() { return this.it.startsWith('Box') || this.it === 'ChickenSingle' || this.it === 'Soda'; }
  shot(p) {
    const pos = this.position.topLeft(), c = p.cmds;
    if (this.it.startsWith('Box')) {
      this.alive = false;
      const content = BOX_CONTENT[this.it];
      if (content === 'balloon') c.addActor(T('Balloon'), pos.offset(0, -H));
      else if (content) c.addActor(content, pos);
      c.addParticleFirework(pos, 4);
      c.addSound('BOXEXPLODE');
      return Absorb;
    }
    if (this.it === 'ChickenSingle') {
      this.alive = false; c.addActor(T('Item', { it: 'ChickenDouble' }), pos); return Absorb;
    }
    if (this.it === 'Soda') { this.alive = false; c.addActor(T('SodaFlying'), pos); return Absorb; }
    return Ignore;
  }
  isInForeground() { return true; }
  isAlive() { return this.alive; }
  backgroundTileStrategy() { return BG.CopyFromLeft; }
}
