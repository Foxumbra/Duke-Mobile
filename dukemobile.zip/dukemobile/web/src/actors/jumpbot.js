// SPDX-License-Identifier: AGPL-3.0-or-later
// Derived from FreeNukum actor/jumpbot.rs (c) Wolfgang Silbermayr, ported to JavaScript.
import {
  ANIMATION_JUMPBOT, OBJECT_ENEMY_GUNFIRE_LEFT, OBJECT_ENEMY_GUNFIRE_RIGHT,
  TILE_WIDTH as W, TILE_HEIGHT as H, HALFTILE_WIDTH as HW,
} from '../consts.js';
import { RangedIterator, Dir, dirFactor } from '../rect.js';
import { Actor, BG, Absorb, T } from './base.js';

const JUMP_PROFILE = [[10, 36], [16, 16], [0, 8], [8, 4], [0, 2], [8, 1], [0, 1], [8, 0], [0, 0], [8, 0], [0, 0], [8, -1], [0, -1]];
const STANDING_DURATION = 10;

export class JumpBot extends Actor {
  constructor(x, y) {
    super(x, y - H, W * 2, H * 2);
    this.orientation = Dir.Left; this.tile = ANIMATION_JUMPBOT;
    this.frame = new RangedIterator(STANDING_DURATION); this.steamFrame = new RangedIterator(8);
    this.state = 'Falling'; this.health = 'Healthy';
  }
  turnTowardsHero(g) {
    const hx = g.center().x, bx = this.position.center().x;
    if (hx < bx) this.orientation = Dir.Left; else if (hx > bx) this.orientation = Dir.Right;
  }
  act(p) {
    const hg = p.hero.position.geometry, f = this.frame;
    switch (this.state) {
      case 'StandingBeforeShot':
        if (f.isFirst()) { this.state = 'LoadingShot'; f.reset(1); this.turnTowardsHero(hg); }
        break;
      case 'LoadingShot':
        if (f.isFirst()) { this.state = 'FiringShot'; f.reset(1); }
        break;
      case 'FiringShot':
        if (f.isFirst()) {
          this.state = 'StandingBeforeJump'; f.reset(STANDING_DURATION); this.turnTowardsHero(hg);
          const sp = this.orientation === Dir.Left ? this.position.topLeft().offset(-W, 6) : this.position.topRight().offset(0, 6);
          p.cmds.addActor(T('HostileShot', { dir: this.orientation }), sp);
        }
        break;
      case 'StandingBeforeJump':
        if (f.isFirst()) { this.state = 'Jumping'; f.reset(JUMP_PROFILE.length); this.turnTowardsHero(hg); }
        break;
      case 'Jumping':
        if (f.isFirst()) { this.state = 'Falling'; f.reset(1); this.turnTowardsHero(hg); }
        break;
      case 'Falling':
        if (p.tiles.rectStandsOnGroundPartially(this.position)) { this.state = 'Landing'; f.reset(1); this.turnTowardsHero(hg); }
        break;
      case 'Landing':
        if (f.isFirst()) { this.state = 'StandingBeforeShot'; f.reset(STANDING_DURATION); this.turnTowardsHero(hg); }
        break;
    }
    if (this.state === 'Jumping') {
      const [x, y] = JUMP_PROFILE[f.current];
      p.tiles.pushRectVertically(this.position, -y);
      p.tiles.pushRectHorizontally(this.position, dirFactor(this.orientation) * x);
    } else if (this.state === 'Falling') {
      p.tiles.rectFallDown(this.position, H);
    }
    if (this.steamFrame.isFirst()) {
      let s1 = this.position.topLeft().offset(W, -8), s2 = this.position.topLeft().offset(0, -8);
      if (this.orientation === Dir.Right) [s1, s2] = [s2, s1];
      if (this.health === 'Hurt1') p.cmds.addActor(T('SingleAnimation', { a: 'Steam' }), s1);
      else if (this.health === 'Hurt2') {
        p.cmds.addActor(T('SingleAnimation', { a: 'Steam' }), s1);
        p.cmds.addActor(T('SingleAnimation', { a: 'Steam' }), s2);
      }
    }
    this.frame.next(); this.steamFrame.next();
    this.tile = this.orientation === Dir.Left ? ANIMATION_JUMPBOT : ANIMATION_JUMPBOT + 12;
  }
  render(r) {
    const t = this.tile, x = this.position.x, y = this.position.y;
    const quad = (ox, oy, a, b, c, d) => {
      r.placeTile(t + a, ox, oy); r.placeTile(t + b, ox + W, oy);
      r.placeTile(t + c, ox, oy + H); r.placeTile(t + d, ox + W, oy + H);
    };
    switch (this.state) {
      case 'StandingBeforeShot': case 'StandingBeforeJump': quad(x, y, 0, 1, 2, 3); break;
      case 'LoadingShot': quad(x, y, 0, 1, 4, 5); break;
      case 'FiringShot':
        quad(x, y, 0, 1, 2, 3);
        if (this.orientation === Dir.Left) r.placeTile(OBJECT_ENEMY_GUNFIRE_LEFT, x - W, y + 8);
        else r.placeTile(OBJECT_ENEMY_GUNFIRE_RIGHT, this.position.right(), y + 8);
        break;
      case 'Jumping': case 'Falling': {
        const oy = y - H / 2;
        r.placeTile(t + 6, x, oy); r.placeTile(t + 7, x + W, oy);
        r.placeTile(t + 8, x, oy + H); r.placeTile(t + 9, x + W, oy + H);
        r.placeTile(t + 10, x, oy + 2 * H); r.placeTile(t + 11, x + W, oy + 2 * H);
        break;
      }
      case 'Landing': quad(x, y + 1, 0, 1, 2, 3); break;
    }
  }
  canGetShot() { return true; }
  shot(p) {
    const at = this.position.topLeft();
    if (this.health === 'Healthy') this.health = 'Hurt1';
    else if (this.health === 'Hurt1') {
      p.cmds.addParticleFirework(at, 4); p.hero.score.add(2500); p.cmds.addSound('SMALLDEATH');
      this.health = 'Hurt2';
    } else if (this.health === 'Hurt2') {
      p.cmds.addActor(T('SingleAnimation', { a: 'Explosion' }), at.offset(HW, 0));
      p.cmds.addParticleFirework(at, 4); p.hero.score.add(2500); p.cmds.addSound('SMALLDEATH');
      this.health = 'Dead';
    }
    return Absorb;
  }
  isInForeground() { return true; }
  hurtsHero(hero) { return this.position.hasIntersection(hero.position.geometry); }
  isAlive() { return this.health !== 'Dead'; }
  backgroundTileStrategy() { return BG.CopyFromLeft; }
  actsWhileInvisible() { return this.state === 'Jumping' || this.state === 'Falling'; }
}
