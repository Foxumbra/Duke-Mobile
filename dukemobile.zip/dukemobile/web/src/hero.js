// SPDX-License-Identifier: AGPL-3.0-or-later
// Derived from FreeNukum hero.rs (c) Wolfgang Silbermayr, ported to JavaScript.

import {
  HERO_FALLING_LEFT, HERO_FALLING_RIGHT, HERO_JUMPING_LEFT, HERO_JUMPING_LEFT_SOMERSAULT,
  HERO_JUMPING_RIGHT, HERO_JUMPING_RIGHT_SOMERSAULT, HERO_NUM_WALKING, HERO_SKELETON_LEFT,
  HERO_SKELETON_RIGHT, HERO_STANDING_LEFT, HERO_STANDING_LEFT_SHOOTING, HERO_STANDING_RIGHT,
  HERO_STANDING_RIGHT_SHOOTING, HERO_WALKING_LEFT, HERO_WALKING_RIGHT, LEVEL_HEIGHT, LEVEL_WIDTH,
  TILE_WIDTH as W, TILE_HEIGHT as H, HALFTILE_WIDTH as HW, KeyColor,
} from './consts.js';
import { Rect, RangedIterator, Dir, dirFactor } from './rect.js';

const JUMP_PROFILE_DEFAULT = [13, 11, 9, 7, 5, 3, 0, 0, 0];
const JUMP_PROFILE_HIGH = [15, 13, 11, 9, 7, 5, 3, 1, 0];

export const Motion = Object.freeze({ NotMoving: 0, Walking: 1 });

export class Position {
  constructor() { this.geometry = new Rect(0, 0, W, H * 2); }
  reset() { this.geometry = new Rect(0, 0, W, H * 2); }
  moveTo(x, y) {
    this.geometry.x = Math.min(x, LEVEL_WIDTH * W);
    this.geometry.y = Math.min(y, LEVEL_HEIGHT * H);
  }
  moveXTo(x) { this.moveTo(x, this.geometry.y); }
  moveYTo(y) { this.moveTo(this.geometry.x, y); }
  pushVertically(tiles, offset) {
    if (offset === 0) return 0;
    const g = this.geometry.clone();
    g.y += offset;
    if (!tiles.collides(g)) { this.moveYTo(g.y); return offset; }
    const abs = Math.abs(offset), direction = Math.sign(offset);
    for (let i = 0; i < abs; i++) {
      g.offset(0, -direction);
      if (!tiles.collides(g)) { this.moveYTo(g.y); return i * direction; }
    }
    return 0;
  }
  pushHorizontally(tiles, offset) {
    if (offset === 0) return 0;
    const g = this.geometry.clone();
    g.offset(offset, 0);
    if (!tiles.collides(g)) { this.moveXTo(g.x); return offset; }
    const abs = Math.abs(offset), direction = Math.sign(offset);
    for (let i = 0; i < abs; i++) {
      g.offset(-direction, 0);
      if (!tiles.collides(g)) { this.moveXTo(g.x); return i * direction; }
    }
    return 0;
  }
}

export class Immunity {
  static DURATION = 16;
  constructor() { this.countdown = 0; }
  reset() { this.countdown = 0; }
  enable() { this.countdown = Immunity.DURATION; }
  heroInvisible() { return this.countdown % 2 > 0; }
  heroSkeleton() { return this.countdown === Immunity.DURATION; }
  heroIsProtected() { return this.countdown > 0; }
  countDown() { if (this.countdown > 0) this.countdown -= 1; }
}

export class Score {
  constructor() { this.count = 0; }
  add(n) { this.count += n; }
  reset() { this.count = 0; }
  setValue(v) { this.count = v; }
  value() { return this.count; }
}

export class Health {
  static MAX = 8;
  constructor() { this.life = 8; } // null means dead
  reset() { this.life = Health.MAX; }
  set(n) { this.life = Math.min(Health.MAX, n); }
  increase(n) { if (this.life !== null) this.life = Math.min(Health.MAX, this.life + n); }
  decrease(n) {
    if (this.life === null) return;
    this.life = this.life < n ? null : this.life - n;
  }
  fillMax() { this.life = Health.MAX; }
  kill() { this.life = null; }
}

export class Firepower {
  static MAX = 4;
  constructor() { this.shots = 1; }
  increase(n) { this.shots = Math.min(Firepower.MAX, this.shots + n); }
  set(n) { this.shots = Math.min(Firepower.MAX, Math.max(1, n)); }
  reset() { this.shots = 1; }
  numShots() { return this.shots; }
}

/** Inventory items are strings: 'key:red', 'boot', 'glove', 'clamp', 'accesscard' */
export const Item = Object.freeze({
  Boot: 'boot', Glove: 'glove', Clamp: 'clamp', AccessCard: 'accesscard',
  Key: (c) => 'key:' + c,
});

export class Inventory {
  constructor() { this.items = new Set(); }
  reset() { this.items.clear(); }
  clear() { this.items.clear(); }
  getItems() { return new Set(this.items); }
  setItems(s) { this.items = new Set(s); }
  set(i) { this.items.add(i); }
  unset(i) { this.items.delete(i); }
  isSet(i) { return this.items.has(i); }
}

export class FetchedLetterState {
  constructor() { this.last = null; }
  picked(l) {
    const prev = this.last;
    if (l === 'D') this.last = 'D';
    else if (prev === 'D' && l === 'U') this.last = 'U';
    else if (prev === 'U' && l === 'K') this.last = 'K';
    else if (prev === 'K' && l === 'E') this.last = 'E';
    else this.last = null;
  }
  succeeded() { return this.last === 'E'; }
  reset() { this.last = null; }
}

export class Hero {
  constructor() {
    this.position = new Position();
    this.score = new Score();
    this.health = new Health();
    this.firepower = new Firepower();
    this.inventory = new Inventory();
    this.fetchedLetterState = new FetchedLetterState();
    this.immunity = new Immunity();
    this.hidden = false;
    this.direction = Dir.Right;
    this.motion = Motion.NotMoving;
    this.isShooting = false;
    this.state = { kind: 'Falling' };
    this.getsHurt = false;
  }

  reset() {
    this.position.reset(); this.score.reset(); this.health.reset(); this.firepower.reset();
    this.inventory.reset(); this.fetchedLetterState.reset(); this.immunity.reset();
    this.hidden = false; this.direction = Dir.Right; this.motion = Motion.NotMoving;
    this.isShooting = false; this.state = { kind: 'Falling' }; this.getsHurt = false;
  }

  resetForLevel() {
    this.direction = Dir.Right;
    for (const c of Object.values(KeyColor)) this.inventory.unset(Item.Key(c));
    this.fetchedLetterState.reset(); this.immunity.reset();
    this.hidden = false; this.motion = Motion.NotMoving; this.isShooting = false;
    this.state = { kind: 'Falling' }; this.getsHurt = false;
  }

  enterLevel(x, y) {
    this.position.geometry.x = x; this.position.geometry.y = y;
    this.resetForLevel();
  }

  render(r) {
    if (this.hidden || this.immunity.heroInvisible()) return;
    let px = this.position.geometry.x - HW, py = this.position.geometry.y;
    const left = this.direction === Dir.Left;
    const s = this.state;
    let base;
    if (this.immunity.heroSkeleton()) base = left ? HERO_SKELETON_LEFT : HERO_SKELETON_RIGHT;
    else if (s.kind === 'Standing') {
      if (this.isShooting) base = left ? HERO_STANDING_LEFT_SHOOTING : HERO_STANDING_RIGHT_SHOOTING;
      else base = left ? HERO_STANDING_LEFT : HERO_STANDING_RIGHT;
    } else if (s.kind === 'Walking') {
      base = (left ? HERO_WALKING_LEFT : HERO_WALKING_RIGHT) + 4 * s.frame.current;
    } else if (s.kind === 'Jumping') {
      if (s.somersault) base = (left ? HERO_JUMPING_LEFT_SOMERSAULT : HERO_JUMPING_RIGHT_SOMERSAULT) + 4 * Math.floor(s.frame.current / 2);
      else base = left ? HERO_JUMPING_LEFT : HERO_JUMPING_RIGHT;
    } else base = left ? HERO_FALLING_LEFT : HERO_FALLING_RIGHT;
    r.placeTile(base, px, py);
    r.placeTile(base + 1, px + W, py);
    r.placeTile(base + 2, px, py + H);
    r.placeTile(base + 3, px + W, py + H);
  }

  wouldCollide(tiles, x, y) {
    const d = this.position.geometry.clone(); d.x = x; d.y = y;
    return tiles.collides(d);
  }

  jump(tiles, cmds) {
    if (tiles.rectStandsOnGroundPartially(this.position.geometry)) {
      let somersault = false;
      if (this.inventory.isSet(Item.Boot)) {
        somersault = this.motion === Motion.Walking && Math.floor(Math.random() * 5) === 0;
      }
      const frame = new RangedIterator(JUMP_PROFILE_DEFAULT.length);
      this.switchState({ kind: 'Jumping', frame, somersault }, cmds);
    }
  }

  switchState(ns, cmds) {
    const os = this.state.kind, nk = ns.kind;
    if (os === nk) { /* same state: nothing */ }
    else if ((os === 'Jumping' || os === 'Falling') && nk === 'Standing') {
      cmds.addActor({ t: 'SingleAnimation', a: 'DustCloud' },
        { x: this.position.geometry.x, y: this.position.geometry.y + H });
      cmds.addSound('PLAYERLAND');
    } else if (os === 'Walking' && nk === 'Standing') { /* nothing */ }
    else if (nk === 'Walking') { /* nothing */ }
    else if (nk === 'Jumping') cmds.addSound('PLAYERJUMP');
    this.state = ns;
  }

  act(tiles, cmds) {
    const g = this.position.geometry;
    this.immunity.countDown();
    if (!this.immunity.heroIsProtected() && this.getsHurt) {
      this.immunity.enable();
      this.health.decrease(1);
      cmds.addSound('PLAYERHIT');
      if (this.state.kind === 'Jumping') this.switchState({ kind: 'Falling' }, cmds);
    }

    const walkingState = () => ({ kind: 'Walking', frame: new RangedIterator(HERO_NUM_WALKING) });
    switch (this.state.kind) {
      case 'Standing':
        if (tiles.rectStandsOnGroundPartially(g)) {
          if (this.motion === Motion.Walking) this.switchState(walkingState(), cmds);
        } else this.switchState({ kind: 'Falling' }, cmds);
        break;
      case 'Walking':
        if (!tiles.rectStandsOnGroundPartially(g)) this.switchState({ kind: 'Falling' }, cmds);
        else if (this.motion !== Motion.Walking) this.switchState({ kind: 'Standing' }, cmds);
        break;
      case 'Falling':
        if (tiles.rectStandsOnGroundPartially(g)) {
          this.switchState(this.motion === Motion.Walking ? walkingState() : { kind: 'Standing' }, cmds);
        }
        break;
      case 'Jumping':
        if (this.state.frame.finishedCycles > 0) this.switchState({ kind: 'Falling' }, cmds);
        break;
    }

    if (this.motion === Motion.Walking) {
      const offset = HW * dirFactor(this.direction);
      const moved = tiles.pushRectHorizontally(g, offset);
      if (moved !== 0 && tiles.rectStandsOnGroundPartially(g)) cmds.addSound('WALKING');
    }

    switch (this.state.kind) {
      case 'Walking': this.state.frame.next(); break;
      case 'Jumping': {
        const fr = this.state.frame;
        const profile = this.inventory.isSet(Item.Boot) ? JUMP_PROFILE_HIGH : JUMP_PROFILE_DEFAULT;
        const distance = profile[fr.current];
        const moved = tiles.pushRectVertically(g, -distance);
        fr.next();
        if (moved !== -distance) {
          this.switchState({ kind: 'Falling' }, cmds);
          cmds.addSound('HITHEAD');
        }
        break;
      }
      case 'Falling': tiles.pushRectVertically(g, 8); break;
    }
  }

  createSavegame(gameId, finishedLevel) {
    const inv = [...this.inventory.getItems()].filter((i) => ['boot', 'glove', 'clamp'].includes(i));
    return {
      gameId, firepower: this.firepower.numShots(), finishedLevel,
      health: this.health.life ?? 0, inventory: inv, score: this.score.value(),
    };
  }
}
