plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.dukemobile"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.dukemobile"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

// The game itself is the web app in ../../web. Copy it into the APK's assets at build time so there is
// a single source of truth. The original game data is NOT bundled; players import their own files.
val copyWeb by tasks.registering(Copy::class) {
    from("../../web")
    into(layout.buildDirectory.dir("generated/webassets/www"))
}
android.sourceSets.getByName("main").assets.srcDir(layout.buildDirectory.dir("generated/webassets"))
tasks.matching { it.name.startsWith("merge") && it.name.endsWith("Assets") }.configureEach { dependsOn(copyWeb) }

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("androidx.activity:activity-ktx:1.9.1")
}
